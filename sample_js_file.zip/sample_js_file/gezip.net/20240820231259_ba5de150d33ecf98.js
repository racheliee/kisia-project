function Yn(a,b,c,d) {
Zn(new $n(a,b,c,d))
}