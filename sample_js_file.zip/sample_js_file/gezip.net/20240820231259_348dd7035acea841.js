function rm(a,b) {
var c=a.indexOf("11");if(c===-1)throw Error("Expected section bitstring but not found in ["+a+"] part of ["+b+"]");return a.slice(0,c+2)
}