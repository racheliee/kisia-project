function yg(a) {
return Qd(a,wg,3)
}