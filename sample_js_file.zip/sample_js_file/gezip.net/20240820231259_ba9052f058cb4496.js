function Qf(a) {
a.g=!1;if(a.i!=a.j.google_js_reporting_queue){if(Of())for(var b=a.i,c=Rf,d=b.length,e=typeof b==="string"?b.split(""):b,f=0;f<d;f++)f in e&&c.call(void 0,e[f],f,b);a.i.length=0}
}