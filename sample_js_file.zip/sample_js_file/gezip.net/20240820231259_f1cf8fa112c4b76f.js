function jg(a,b) {
return a?b?hg(a,b):{success:!1,P:1}:{success:!0,value:!0}
}