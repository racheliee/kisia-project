function ih(a,b,c,d,e,f) {
fh.call(this,a,b,"https://pagead2.googlesyndication.com/pagead/ping",eh,c===void 0?1E3:c,d===void 0?100:d,(e===void 0?!1:e)&&!!t.globalThis.fetch,f)
}