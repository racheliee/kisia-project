function Va(a) {
z.setTimeout(function(){throw a;},0)
}