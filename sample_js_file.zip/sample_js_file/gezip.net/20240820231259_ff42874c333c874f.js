function ja(a) {
return a.raw=a
}