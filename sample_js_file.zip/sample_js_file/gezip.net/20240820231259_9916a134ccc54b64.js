function Rm(a) {
this.A=a;this.g=null
}