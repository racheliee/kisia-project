function oi(a) {
a=a.g.slice(0).map(pi);a=JSON.stringify(a);return $e(a)
}