function g(b) {
f(b,1),a(this).off(b.type,g)
}