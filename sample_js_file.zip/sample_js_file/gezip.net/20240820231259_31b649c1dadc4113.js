function Q(a,b,c) {
this.l=F(a,b,c)
}