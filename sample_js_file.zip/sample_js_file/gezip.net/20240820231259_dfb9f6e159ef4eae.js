function Wq(a,b) {
var c=R(kf);c.i=function(d,e){return Ih(5,a,function(){return!1})(d,e,b)};c.u=function(d,e){return Ih(6,a,function(){return 0})(d,e,b)};c.g=function(d,e){return Ih(7,a,function(){return""})(d,e,b)};c.B=function(d,e){return Ih(8,a,function(){return[]})(d,e,b)};c.j=function(d,e){return Ih(17,a,function(){return[]})(d,e,b)};c.C=function(){Ih(15,a,function(){})(b)}
}