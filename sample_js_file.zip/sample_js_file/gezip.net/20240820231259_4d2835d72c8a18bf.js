function ce(a,b) {
var c=c===void 0?0:c;return Yd(Pc(wd(a,b)),c)
}