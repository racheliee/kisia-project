function Yr(a) {
var b=X(window).head_tag_slot_vars,c=a.getAttribute("src")||"";if((a=Se(c,"client")||a.getAttribute("data-ad-client")||"")&&a!==b.google_ad_client)throw new W("Warning: Do not add multiple property codes with AdSense tag to avoid seeing unexpected behavior. These codes were found on the page "+a+", "+b.google_ad_client);
}