function Ia(a,b) {
var c=Ja("CLOSURE_FLAGS");a=c&&c[a];return a!=null?a:b
}