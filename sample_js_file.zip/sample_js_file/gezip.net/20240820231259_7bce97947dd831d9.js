function cc(a) {
return a!==null&&typeof a==="object"&&!Array.isArray(a)&&a.constructor===Object
}