function sidebar_login(f) {

	if (f.mb_id.value == '') {
		alert('아이디를 입력해 주세요.');
		f.mb_id.focus();
		return false;
	}
	if (f.mb_password.value == '') {
		alert('비밀번호를 입력해 주세요.');
		f.mb_password.focus();
		return false;
	}
	return true;

}