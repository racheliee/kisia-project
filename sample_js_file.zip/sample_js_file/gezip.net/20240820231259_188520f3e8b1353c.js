function re(a) {
this.l=F(a)
}