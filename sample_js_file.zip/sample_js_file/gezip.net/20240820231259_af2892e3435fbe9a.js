function Ji(a,b) {
b=b===void 0?[]:b;this.g=a;this.defaultValue=b
}