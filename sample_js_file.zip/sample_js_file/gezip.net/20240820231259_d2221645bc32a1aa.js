function Vl(a,b,c,d) {
c||(c=function(){});if(typeof a.j.__tcfapi==="function")a=a.j.__tcfapi,a(b,2,c,d);else if(Wl(a)){Xl(a);var e=++a.N;a.C[e]=c;a.g&&(c={},a.g.postMessage((c.__tcfapiCall={command:b,version:2,callId:e,parameter:d},c),"*"))}else c({},!1)
}