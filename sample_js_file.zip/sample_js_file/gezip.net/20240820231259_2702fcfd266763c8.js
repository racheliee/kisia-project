function wrestAlpha(fld) {

    if (!wrestTrim(fld)) return;

    var pattern = /(^[a-zA-Z]+$)/;

    if (!pattern.test(fld.value)) {
        if (wrestFld == null) {
            wrestMsg = wrestItemname(fld) + " : " + aslang[30] + "\n";
            wrestFld = fld;
        }
    }

}