function Or(a) {
var b=document.getElementsByTagName("INS");for(var c=0,d=b[c];c<b.length;d=b[++c]){var e=d;if(Kr(e)&&e.dataset.adsbygoogleStatus!=="reserved"&&(!a||d.id===a))return d}return null
}