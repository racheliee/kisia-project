function Bd(a,b,c) {
return Ad(a,b,Cd(a,Dd,c))!==void 0
}