function Wf(a,b) {
var c="https://pagead2.googlesyndication.com"+b,d=Xf(a)-b.length;if(d<0)return"";a.g.sort(function(p,n){return p-n});b=null;for(var e="",f=0;f<a.g.length;f++)for(var g=a.g[f],h=a.i[g],k=0;k<h.length;k++){if(!d){b=b==null?g:b;break}var l=Uf(h[k],a.j,",$");if(l){l=e+l;if(d>=l.length){d-=l.length;c+=l;e=a.j;break}b=b==null?g:b}}a="";b!=null&&(a=e+"trn="+b);return c+a
}