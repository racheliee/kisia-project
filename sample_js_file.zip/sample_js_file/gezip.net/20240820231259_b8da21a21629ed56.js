function ap(a,b,c,d) {
var e=Ao(a,b),f=e.Gb,g=e.Wb;c.appendChild(g);bp(a,c,b);var h;c=(h=b.google_start_time)!=null?h:Ua;h=(new Date).getTime();b.google_lrv=Bo({Fa:Fm(),La:O(d,2)});b.google_async_iframe_id=f;b.google_start_time=c;b.google_bpp=h>c?h-c:1;a.google_sv_map=a.google_sv_map||{};a.google_sv_map[f]=b;$o(a,function(){var k=g;if(!k||!k.isConnected)if(k=a.document.getElementById(String(b.google_async_iframe_id)+"_host"),k==null)throw Error("no_div");(k=a.google_sa_impl({pubWin:a,vars:b,innerInsElement:k}))&& 
hl(911,k)})
}