function s(e,n) {
r=n,l(t,r?"scrollstart":"scrollstop",e)
}