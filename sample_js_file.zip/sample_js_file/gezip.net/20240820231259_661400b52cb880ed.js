function W(a) {
a=a===void 0?"":a;var b=Error.call(this);this.message=b.message;"stack"in b&&(this.stack=b.stack);this.name="TagError";this.message=a?"adsbygoogle.push() error: "+a:"";Error.captureStackTrace?Error.captureStackTrace(this,W):this.stack=Error().stack||""
}