function hideSideView() {

        if (document.getElementById("nameContextMenu"))
            divDisplay ("nameContextMenu", 'none');
    
}