function Jh(a) {
Hh(5,xh,a);Hh(6,yh,a);Hh(7,zh,a);Hh(8,Ah,a);Hh(17,Bh,a);Hh(13,Eh,a);Hh(15,Gh,a)
}