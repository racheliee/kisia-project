function Ag(a,b) {
return le(a,1,b)
}