function doc_write(cont) {

    document.write(cont);

}