function Jk(a,b) {
b=b.google_js_reporting_queue=b.google_js_reporting_queue||[];b.length<2048&&b.push(a)
}