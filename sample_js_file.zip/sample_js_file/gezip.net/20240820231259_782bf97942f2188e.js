function ym(a) {
if(/[^01]/.test(a))throw Error("Input bitstring "+a+" is malformed!");this.i=a;this.g=0
}