function vd(a,b,c,d) {
if(!(4&b))return!0;if(c==null)return!1;!d&&c===0&&(4096&b||8192&b)&&(a.constructor[Sb]=(a.constructor[Sb]|0)+1)<5&&oc();return c===0?!1:!(c&b)
}