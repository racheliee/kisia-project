function A() {
g=!0
}