function c() {
d.push({anchor:e.anchor,position:e.position});return e.anchor==b.anchor&&e.position==b.position
}