function Cd(a,b,c) {
return Pd(a,b)===c?c:-1
}