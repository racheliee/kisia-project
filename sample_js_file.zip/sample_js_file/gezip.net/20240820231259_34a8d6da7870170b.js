function zb() {
if(!wb){wb={};for(var a="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""),b=["+/=","+/","-_=","-_.","-_"],c=0;c<5;c++){var d=a.concat(b[c].split(""));vb[c]=d;for(var e=0;e<d.length;e++){var f=d[e];wb[f]===void 0&&(wb[f]=e)}}}
}