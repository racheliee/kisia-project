function no() {
var a=this;this.promise=new t.Promise(function(b,c){a.resolve=b;a.reject=c})
}