function Gb(a) {
if(a<0){Fb(-a);var b=x(Hb(Db,Eb));a=b.next().value;b=b.next().value;Db=a>>>0;Eb=b>>>0}else Fb(a)
}