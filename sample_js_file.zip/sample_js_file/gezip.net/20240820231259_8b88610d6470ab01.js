function rq(a) {
var b=S.document;if(b.currentScript)return qq(b.currentScript,a);b=x(b.scripts);for(var c=b.next();!c.done;c=b.next())if(qq(c.value,a)===0)return 0;return 1
}