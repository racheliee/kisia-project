function Xd(a,b) {
a=wd(a,b);a!=null&&(typeof a==="bigint"?Gc(a)?a=Number(a):(a=BigInt.asIntN(64,a),a=Gc(a)?Number(a):String(a)):a=Kc(a)?typeof a==="number"?Uc(a):Rc(a):void 0);return a
}