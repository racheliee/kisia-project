function Wg(a) {
var b=new Vg;return Ud(b,4,Xg,a)
}