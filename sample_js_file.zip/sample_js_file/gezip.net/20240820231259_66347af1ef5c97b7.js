function Sj(a,b) {
return(a=Tj(a,b))?a.y:0
}