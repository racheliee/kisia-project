function divDisplay(id, act) {

        selectBoxVisible();

        document.getElementById(id).style.display = act;
    
}