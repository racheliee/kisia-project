function apms_print(url) {


	if(!url) url = g5_purl;

	if (url.indexOf('?') > 0) {
		url	= url + '&pim=1&ipwm=1';
	} else {
		url	= url + '?pim=1&ipwm=1';
	}
	window.open(url, 'print', "width=760,height=720,scrollbars=1");
	return false;

}