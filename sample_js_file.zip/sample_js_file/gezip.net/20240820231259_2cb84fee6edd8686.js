function nn(a,b) {
a=ln(kn(a.location.pathname)).replace(/(^\/)|(\/$)/g,"");var c=$e(a),d=on(a);return u(b,"find").call(b,function(e){if(zd(e,ok,7)){var f=K(e,ok,7);f=Pc(wd(f,1))}else f=Pc(wd(e,1));e=zd(e,ok,7)?M(K(e,ok,7),2):2;if(typeof f!=="number")return!1;switch(e){case 1:return f==c;case 2:return d[f]||!1}return!1})||null
}