function en(a) {
return zd(a,vm,2)?K(a,vm,2):wm()
}