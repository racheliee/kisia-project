function Sg(a) {
this.l=F(a)
}