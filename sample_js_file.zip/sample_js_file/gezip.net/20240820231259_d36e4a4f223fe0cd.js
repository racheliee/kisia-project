function tb(a) {
tb[" "](a);return a
}