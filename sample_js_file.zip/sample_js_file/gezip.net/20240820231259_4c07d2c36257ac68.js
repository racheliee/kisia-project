function rc(a,b) {
var c=sc;if(!b(a)){var d,e;b=(e=(d=typeof c==="function"?c():c)==null?void 0:d.concat("\n"))!=null?e:"";throw Error(b+String(a));}
}