function is_sidebar() {

	var side;
	var width = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
	if(width > 480) {
		side = 'right';
	} else {
		side = 'left';
	}
	return side;

}