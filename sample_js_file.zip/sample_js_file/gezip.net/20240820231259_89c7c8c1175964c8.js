function nk(a) {
this.l=F(a)
}