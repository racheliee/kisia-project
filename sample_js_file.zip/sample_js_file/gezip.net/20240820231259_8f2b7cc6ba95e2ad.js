function set_comment_token(f) {

    if(typeof f.token === "undefined")
        $(f).prepend('<input type="hidden" name="token" value="">');

	$.ajax({
		url: g5_bbs_url+"/ajax.comment_token.php",
		type: "GET",
		dataType: "json",
		async: false,
		cache: false,
		success: function(data, textStatus) {
			f.token.value = data.token;
		}
	});

}