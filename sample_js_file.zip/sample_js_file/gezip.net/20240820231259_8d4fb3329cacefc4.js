function textarea_increase(id, row) {

    document.getElementById(id).rows += row;

}