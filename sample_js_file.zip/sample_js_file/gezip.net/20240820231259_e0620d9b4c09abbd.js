function T(a,b) {
this.g=a;this.defaultValue=b===void 0?!1:b
}