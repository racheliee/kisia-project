function Tn(a) {
gl("atf_ad_settings_from_ppabg",{p_s:a},.01)
}