function Cg(a) {
this.l=F(a)
}