function Fn(a) {
X(S).allow_second_reactive_tag=a
}