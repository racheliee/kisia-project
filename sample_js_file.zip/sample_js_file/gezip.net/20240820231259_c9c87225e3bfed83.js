function wk(a) {
this.l=F(a)
}