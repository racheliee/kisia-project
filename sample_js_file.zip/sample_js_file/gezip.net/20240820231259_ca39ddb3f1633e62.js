function fh(a,b,c,d,e,f,g,h) {
dh.call(this,a,b);this.N=c;this.G=d;this.W=e;this.D=f;this.F=g;this.B=h;this.g=[];this.i=null;this.C=!1
}