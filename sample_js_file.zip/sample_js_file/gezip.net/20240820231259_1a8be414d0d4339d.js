function ti(a) {
switch(a){case 1:return new ri(null,{google_ad_semantic_area:"mc"});case 2:return new ri(null,{google_ad_semantic_area:"h"});case 3:return new ri(null,{google_ad_semantic_area:"f"});case 4:return new ri(null,{google_ad_semantic_area:"s"});default:return null}
}