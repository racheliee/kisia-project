function apms_comment(id) {

	var str;
	var c_url;
	if(id == 'viewcomment') {
		c_url = './write_comment_update.page.php';
	} else {
		c_url = './itemcommentupdate.php';
	}
	var f = document.getElementById("fviewcomment");
	var url = document.getElementById("comment_url").value;
	if (fviewcomment_submit(f)) {
		$.ajax({
			url : c_url,
			type : 'POST',
			cache : false,
			data : $("#fviewcomment").serialize() + "&js=on",
			dataType : "html",
			success : function(data) {
				str = data.substr(0, 2);
				data = data.replace(str,'');
				if(str == "1|") {
					if(data) alert(data);
					return false;
				} else {
					apms_page(id, url);
					document.getElementById("btn_submit").disabled = false;
					document.getElementById('wr_content').value = "";
				}
			},
			error : function(data) {
				alert(aslang[12]);
				return false;
			}
		});
	}

}