function wr() {
var a=new tr;if(U(Gm)){var b=window;if(!b.google_plmetrics&&window.PerformanceObserver){b.google_plmetrics=!0;b=["layout-shift","largest-contentful-paint","first-input","longtask"];a.Ab.lb&&b.push("event");b=x(b);for(var c=b.next();!c.done;c=b.next()){c=c.value;var d={type:c,buffered:!0};c==="event"&&(d.durationThreshold=40);xr(a).observe(d)}yr(a)}}
}