function Dg(a) {
var b=new Cg;return J(b,1,E(a),0)
}