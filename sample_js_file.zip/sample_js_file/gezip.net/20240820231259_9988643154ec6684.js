function Ee(a) {
return a instanceof De&&a.constructor===De?a.g:"type_error:TrustedResourceUrl"
}