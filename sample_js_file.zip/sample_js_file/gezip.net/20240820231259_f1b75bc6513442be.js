function Xh(a) {
if(a.g!=0)throw Error("Already resolved/rejected.");
}