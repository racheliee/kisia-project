function Jl(a,b,c) {
b=Kl[b]||"google_ps_"+b;a=a.S;var d=a[b];return d===void 0?(a[b]=c(),a[b]):d
}