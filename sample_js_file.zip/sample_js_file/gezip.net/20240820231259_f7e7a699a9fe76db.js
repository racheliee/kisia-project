function c(d) {
return a.throw(d)
}