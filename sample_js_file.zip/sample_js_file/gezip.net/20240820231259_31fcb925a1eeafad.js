function li(a) {
this.l=F(a)
}