function gq(a) {
var b=a.g.pc;return b!==null&&b!==0?b:a.g.pc=nf(a.A)
}