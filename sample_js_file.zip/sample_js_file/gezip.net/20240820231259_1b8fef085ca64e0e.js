function ds(a,b) {
(X(S).first_tag_on_page||0)===0&&(X(S).first_tag_on_page=1);if(a.tag_partner){var c=a.tag_partner,d=X(z);d.tag_partners=d.tag_partners||[];d.tag_partners.push(c)}wo(a,b);Ur(a,b)
}