function vg(a) {
this.l=F(a)
}