function Le(a) {
return String(a).replace(/\-([a-z])/g,function(b,c){return c.toUpperCase()})
}