function Ge(a) {
if(Ce===void 0){var b=null;var c=z.trustedTypes;if(c&&c.createPolicy){try{b=c.createPolicy("goog#html",{createHTML:Sa,createScript:Sa,createScriptURL:Sa})}catch(d){z.console&&z.console.error(d.message)}Ce=b}else Ce=b}a=(b=Ce)?b.createScriptURL(a):a;return new De(a,Fe)
}