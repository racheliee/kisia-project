function Aq(a) {
var b={};return Bq((b[0]=new t.Map,b[1]=new t.Map,b[2]=new t.Map,b),a)
}