function yd(a,b,c,d) {
b=d+(+!!(b&512)-1);if(!(b<0||b>=a.length||b>=c))return a[b]
}