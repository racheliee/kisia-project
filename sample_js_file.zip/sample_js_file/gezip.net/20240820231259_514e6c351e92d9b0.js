function Ac(a) {
var b=a;if(wc(b)){if(!/^\s*(?:-?[1-9]\d*|0)?\s*$/.test(b))throw Error(String(b));}else if(vc(b)&&!u(Number,"isSafeInteger").call(Number,b))throw Error(String(b));return zc?BigInt(a):a=xc(a)?a?"1":"0":wc(a)?a.trim()||"0":String(a)
}