function io(a,b,c,d) {
try{var e=nn(a,L(c,uk,7,I()));if(e&&mn(e)){if(ie(e)){var f={},g=new ri(null,(f.google_package=ie(e),f));d=si(d,g)}var h=new xl(a,b,c,e,d);Mk(1E3,function(){var k=new Vh;(new km(a,h,k)).start();return k.i},a).then(function(){hn(a,{atf:1})},function(k){(a.google_ama_state=a.google_ama_state||{}).exception=k;hn(a,{atf:0})})}}catch(k){hn(a,{atf:-1})}
}