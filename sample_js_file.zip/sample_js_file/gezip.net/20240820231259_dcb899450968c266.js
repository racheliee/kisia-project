function ye(a,b) {
var c={},d;for(d in a)b.call(void 0,a[d],d,a)&&(c[d]=a[d]);return c
}