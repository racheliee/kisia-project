function Er(a,b) {
Fr(a,b);var c=a.g[a.g.length-1],d=a.F[b.interactionId];if(d||a.g.length<10||b.duration>c.latency)d?(u(d,"entries").push(b),d.latency=Math.max(d.latency,b.duration)):(b={id:b.interactionId,latency:b.duration,entries:[b]},a.F[b.id]=b,a.g.push(b)),a.g.sort(function(e,f){return f.latency-e.latency}),a.g.splice(10).forEach(function(e){delete a.F[e.id]})
}