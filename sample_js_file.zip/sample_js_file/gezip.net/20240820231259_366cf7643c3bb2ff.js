function we(a,b,c) {
a.addEventListener&&a.addEventListener(b,c,!1)
}