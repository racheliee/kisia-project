function hf() {
var a=gf;gf=[];a=x(a);for(var b=a.next();!b.done;b=a.next()){b=b.value;try{b()}catch(c){}}
}