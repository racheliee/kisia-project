function mi(a) {
var b=a.fb===void 0?void 0:a.fb;var c=a.Cb===void 0?void 0:a.Cb;var d=a.Jb===void 0?void 0:a.Jb;a=a.vb===void 0?void 0:a.vb;this.g=c;this.u=new Zh(b||[]);this.j=a;this.i=d
}