function oh() {
var a={};this.O=(a[3]={},a[4]={},a[5]={},a)
}