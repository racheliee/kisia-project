function h(n) {
for(var m=[], 
r=0,v=0;v<n.length/2;v++)m.push(om(n.slice(r,r+2))),r+=2;return m
}