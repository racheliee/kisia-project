function Bm(a) {
for(var b=Am(a,12),c=[];b--;){var d=!!Am(a,1)===!0,e=Am(a,16);if(d)for(d=Am(a,16);e<=d;e++)c.push(e);else c.push(e)}c.sort(function(f,g){return f-g});return c
}