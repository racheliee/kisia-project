function qg(a,b) {
try{rf({m:Zf(a instanceof Error?a:Error(String(a))),b:P(b,1)||null,v:O(b,2)||null},"rcs_internal")}catch(c){}
}