function Lk(a,b) {
return Kk(a,b,function(c,d){(new Ik).V(c,d)},void 0,!1)
}