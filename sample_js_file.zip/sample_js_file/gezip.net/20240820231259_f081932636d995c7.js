function f(n) {
if(n.length<12)return null;var m=h(n.slice(0,6));m=k(m);n=h(n.slice(8,12));n=l(n);return"1"+m+n+"N"
}