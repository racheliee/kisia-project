function Rj(a,b) {
return!((bf.test(b.google_ad_width)||af.test(a.style.width))&&(bf.test(b.google_ad_height)||af.test(a.style.height)))
}