function Ym(a,b) {
function c(){if(!a.frames[b])if(d.body){var e=We("IFRAME",d);e.style.display="none";e.style.width="0px";e.style.height="0px";e.style.border="none";e.style.zIndex="-1000";e.style.left="-1000px";e.style.top="-1000px";e.name=b;d.body.appendChild(e)}else a.setTimeout(c,5)}var d=a.document;c()
}