function Ih(a,b,c) {
return b[a]||c
}