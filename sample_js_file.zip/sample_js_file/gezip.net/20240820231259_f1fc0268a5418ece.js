function tf(a) {
this.g=a||{cookie:""}
}