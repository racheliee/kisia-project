function mb() {
this.parentNode===Eb[0]&&sb.activatePage(Fb.index(this))
}