function n(v) {
return function(B){m[v]=B;r--;r==0&&l(m)}
}