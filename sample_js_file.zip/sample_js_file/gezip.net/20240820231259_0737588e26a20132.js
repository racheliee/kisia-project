function Jg(a,b) {
return J(a,2,E(b),0)
}