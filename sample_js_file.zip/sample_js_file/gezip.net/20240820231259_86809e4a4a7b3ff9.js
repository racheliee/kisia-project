function T(e) {
while(e&&typeof e.originalEvent!="undefined")e=e.originalEvent;return e
}