function vm(a) {
this.l=F(a)
}