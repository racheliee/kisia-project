function Ql(a) {
var b=new Pl;return G(b,5,Ic(a))
}