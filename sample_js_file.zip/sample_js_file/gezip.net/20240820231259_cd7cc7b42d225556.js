function fk(a,b) {
return Sj(a,b)<Nj(b).clientHeight-100
}