function di(a) {
return a.g!=null?a.getValue():null
}