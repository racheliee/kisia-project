function fg(a) {
this.l=F(a)
}