function dl(a) {
a!=null&&(z.google_measure_js_timing=a);z.google_measure_js_timing||Qf(cl)
}