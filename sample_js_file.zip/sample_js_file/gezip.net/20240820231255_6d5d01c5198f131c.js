function sidebar_empty(id) {


	// Ajax
	switch(id) {
		case 'sidebar-cart' : $('#' + id + '-list').load(sidebar_url + '/cart.php?del=1'); break;
	}

	return false;

}