function Be(a) {
var b={},c;for(c in a)b[c]=a[c];return b
}