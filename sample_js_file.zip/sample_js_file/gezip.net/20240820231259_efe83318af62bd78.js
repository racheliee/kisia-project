function qq(a,b) {
return a instanceof HTMLScriptElement&&b.test(a.src)?0:1
}