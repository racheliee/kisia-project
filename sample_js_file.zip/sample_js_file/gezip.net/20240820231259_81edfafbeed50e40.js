function rn(a) {
return fe(a,1,I())
}