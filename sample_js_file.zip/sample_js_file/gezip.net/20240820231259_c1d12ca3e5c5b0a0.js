function go(a) {
Zl({A:a.A,ka:N(a.g,6),yb:50,Db:function(b){ho(a,b)}})
}