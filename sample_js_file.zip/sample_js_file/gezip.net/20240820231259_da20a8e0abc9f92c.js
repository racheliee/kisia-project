function d(n) {
if(n.length<10)return null;var m=h(n.slice(0,4));m=k(m);n=h(n.slice(6,10));n=l(n);return"1"+m+n+"N"
}