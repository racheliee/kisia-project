function wrestInitialized() {

    for (var i = 0; i < document.forms.length; i++) {
        // onsubmit 이벤트가 있다면 저장해 놓는다.
        if (document.forms[i].onsubmit) {
            document.forms[i].oldsubmit = document.forms[i].onsubmit;
        }
        document.forms[i].onsubmit = wrestSubmit;
    }

}