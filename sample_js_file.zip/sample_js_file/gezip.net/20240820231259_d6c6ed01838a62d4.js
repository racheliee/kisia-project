function hh(a,b,c) {
c=c===void 0?0:c;a.g.size>0||$p(a);c=Math.min(Math.max(0,c),9);var d=a.g.get(c);d?d.push(b):a.g.set(c,[b])
}