function or(a) {
if(!a.sources)return 0;a=a.sources.filter(function(b){return b.previousRect&&b.currentRect});if(a.length>=1){a=a[0];if(a.previousRect.top<a.currentRect.top)return 2;if(a.previousRect.top>a.currentRect.top)return 1}return 0
}