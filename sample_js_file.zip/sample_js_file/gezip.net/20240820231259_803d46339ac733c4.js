function gd(a,b,c,d,e) {
var f=d||c?Vb(a):0;d=d?!!(f&32):void 0;a=Lb(a);for(var g=0;g<a.length;g++)a[g]=fd(a[g],b,c,d,e);c&&c(f,a);return a
}