function bo(a) {
gi(ei(fo(a),function(b){a.i(b,{fromPABGSettings:!0})}),function(){go(a)})
}