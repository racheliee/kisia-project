function sidebar_open(id) {


	var div = $("#sidebar-box");
	var side = is_sidebar();
	var is_div = div.css(side);
	var is_size;
	var is_open;
	var is_show;

	if(id == sidebar_id) {
		if(is_div === sidebar_size) {
			is_show = false;
			ani_sidebar(div, side, '0px'); 
			if(side == "left") {
				sidebar_mask('show');
			} else {
				sidebar_mask('hide');
			}
		} else {
			is_show = false;
			ani_sidebar(div, side, sidebar_size); 
			sidebar_mask('hide');
		}
	} else {
		if(is_div === sidebar_size) {
			is_show = true;
			ani_sidebar(div, side, '0px'); 
		} else {
			is_show = true;
		}

		if(side == "left") {
			sidebar_mask('show');
		} else {
			sidebar_mask('hide');
		}
	}

	// Show
	if(is_show) {
		$('.sidebar-item').hide();

		if(id == "sidebar-user") {
			$('.sidebar-common').hide();
		} else {
			$('.sidebar-common').show();
		}

		switch(id) {
			case 'sidebar-response'	: $('#' + id + '-list').load(sidebar_url + '/response.php'); break;
			case 'sidebar-cart'		: $('#' + id + '-list').load(sidebar_url + '/cart.php'); break;
		}

		$('#' + id).show();
		$('#sidebar-content').scrollTop(0);
	}

	// Save id
	sidebar_id = id;

	return false;

}