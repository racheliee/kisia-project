function ab(a) {
cc.released=0,cc.source=a,cc.slidee="slidee"===a
}