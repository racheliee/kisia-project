function Nd(a) {
if(Mb){var b;return(b=a[Rb])!=null?b:a[Rb]=new t.Map}if(Rb in a)return a[Rb];b=new t.Map;Object.defineProperty(a,Rb,{value:b});return b
}