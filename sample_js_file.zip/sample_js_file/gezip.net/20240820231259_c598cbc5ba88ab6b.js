function wm() {
var a=new vm;return je(a,1,0)
}