function gm(a) {
this.l=F(a)
}