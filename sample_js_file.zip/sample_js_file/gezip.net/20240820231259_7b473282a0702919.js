function he(a,b,c,d) {
return K(a,b,Cd(a,d,c))
}