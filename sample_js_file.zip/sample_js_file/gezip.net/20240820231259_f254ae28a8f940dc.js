function Nb(a) {
return typeof t.Symbol==="function"&&typeof(0,t.Symbol)()==="symbol"?(0,t.Symbol)():a
}