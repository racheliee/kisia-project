function hi(a) {
return new ci(null,a)
}