function sr(a,b) {
return a.sources.reduce(function(c,d){d=b(d);return c?d&&d.width*d.height!==0?d.top<c.top?d:c:c:d},null)
}