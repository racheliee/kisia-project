function hb() {
return eb()?db("Microsoft Edge"):C("Edg/")
}