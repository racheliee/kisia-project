function Dn(a) {
a=X(a);var b=a.space_collapsing||"none";return a.remove_ads_by_default?{eb:!0,Ub:b,Ea:a.ablation_viewport_offset}:null
}