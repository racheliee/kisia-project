function ge(a,b,c) {
return P(a,Cd(a,c,b))
}