function Rg(a,b) {
return J(a,6,E(b),0)
}