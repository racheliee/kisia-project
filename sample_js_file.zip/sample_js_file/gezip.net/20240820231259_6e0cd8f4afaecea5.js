function Yg(a) {
this.l=F(a)
}