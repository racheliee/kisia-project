function xo(a) {
Yn(a.A,a.i,a.g.google_ad_client||"",function(b,c){var d=a.A,e=a.g;X(S).ama_ran_on_page||b&&zo(d,e,b,c)})
}