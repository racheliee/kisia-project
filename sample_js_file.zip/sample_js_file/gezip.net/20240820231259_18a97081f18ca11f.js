function ug(a) {
this.l=F(a)
}