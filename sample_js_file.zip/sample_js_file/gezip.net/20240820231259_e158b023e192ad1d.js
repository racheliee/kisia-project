function ir(a) {
var b=window;var c=c===void 0?null:c;we(b,"message",function(d){try{var e=JSON.parse(d.data)}catch(f){return}!e||e.googMsgType!=="sc-cnf"||c&&/[:|%3A]javascript\(/i.test(d.data)&&!c(e,d)||a(e,d)})
}