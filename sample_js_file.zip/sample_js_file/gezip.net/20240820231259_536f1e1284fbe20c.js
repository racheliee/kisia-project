function Wd(a,b,c) {
var d=a.l,e=Wb(d);gc(e);if(c==null)return H(d,e,b),a;c=ud(c);for(var f=Vb(c),g=f,h=!!(2&f)||!!(2048&f),k=h||Object.isFrozen(c),l=!k&&(void 0===ic||!1),p=!0,n=!0,m=0;m<c.length;m++){var r=c[m];h||(r=!!(Vb(r.l)&2),p&&(p=!r),n&&(n=r))}h||(f|=5,f=p?f|8:f&-9,f=n?f|16:f&-17);if(l||k&&f!==g)c=Lb(c),g=0,f=Gd(f,e),f=Jd(f,e,!0);f!==g&&D(c,f);H(d,e,b,c);return a
}