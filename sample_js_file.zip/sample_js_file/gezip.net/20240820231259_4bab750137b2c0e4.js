function Co(a) {
if(a.google_ad_client)return String(a.google_ad_client);var b,c,d,e;return(e=(d=(b=X(a).head_tag_slot_vars)==null?void 0:b.google_ad_client)!=null?d:(c=a.document.querySelector(".adsbygoogle[data-ad-client]"))==null?void 0:c.getAttribute("data-ad-client"))!=null?e:""
}