function Zl(a) {
var b=a.A;var c=a.ka;var d=a.yb;var e=a.Db;a=$l({A:b,ka:c,ua:a.ua===void 0?!1:a.ua,va:a.va===void 0?!1:a.va});a.g!=null||a.i.message!="tcunav"?e(a):am(b,d).then(function(f){return f.map(bm)}).then(function(f){return f.map(function(g){return cm(b,g)})}).then(e)
}