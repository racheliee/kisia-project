function Cn(a) {
rc(Bn,yc);Bn=a
}