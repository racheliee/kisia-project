function Wk(a,b) {
var c=new ki,d=new ji;b.forEach(function(e){if(he(e,qk,1,tk)){e=he(e,qk,1,tk);if(K(e,Ci,1)&&K(K(e,Ci,1),li,1)&&K(e,Ci,2)&&K(K(e,Ci,2),li,1)){var f=Xk(a,K(K(e,Ci,1),li,1)),g=Xk(a,K(K(e,Ci,2),li,1));if(f&&g)for(f=x(Uk({anchor:f,position:M(K(e,Ci,1),2)},{anchor:g,position:M(K(e,Ci,2),2)})),g=f.next();!g.done;g=f.next())g=g.value,c.set(La(g.anchor),g.position)}K(e,Ci,3)&&K(K(e,Ci,3),li,1)&&(f=Xk(a,K(K(e,Ci,3),li,1)))&&c.set(La(f),M(K(e,Ci,3),2))}else he(e,rk,2,tk)?Yk(a,he(e,rk,2,tk), 
c):he(e,pk,3,tk)&&Zk(a,he(e,pk,3,tk),d)});return new Vk(c,d)
}