function lm(a,b) {
try{var c=a.i,d=c.resolve,e=a.g;Rk(e.g);L(e.j,Ei,1,I());d.call(c,new jm(b))}catch(f){a.i.reject(f)}
}