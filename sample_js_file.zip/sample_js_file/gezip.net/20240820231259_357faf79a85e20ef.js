function vn(a) {
this.l=F(a)
}