function qn(a) {
this.l=F(a)
}