function tn(a) {
this.l=F(a)
}