function sidebar_href(url) {


	$('.sidebar-menu .panel-collapse').hide();

	document.location.href = decodeURIComponent(url);

	return false;

}