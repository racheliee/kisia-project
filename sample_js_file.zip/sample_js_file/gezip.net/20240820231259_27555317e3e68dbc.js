function Kd(a,b,c,d) {
var e=a.l,f=Wb(e);gc(f);if(c==null)return H(e,f,b),a;c=ud(c);var g=Vb(c),h=g,k=!!(2&g)||Object.isFrozen(c),l=!k&&(void 0===ic||!1);if(vd(a,g))for(g=21,k&&(c=Lb(c),h=0,g=Gd(g,f),g=Jd(g,f,!0)),k=0;k<c.length;k++)c[k]=d(c[k]);l&&(c=Lb(c),h=0,g=Gd(g,f),g=Jd(g,f,!0));g!==h&&D(c,g);H(e,f,b,c);return a
}