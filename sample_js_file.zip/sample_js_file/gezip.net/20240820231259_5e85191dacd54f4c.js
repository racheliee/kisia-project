function ls(a) {
a&&a.call&&typeof a==="function"&&window.setTimeout(a,0)
}