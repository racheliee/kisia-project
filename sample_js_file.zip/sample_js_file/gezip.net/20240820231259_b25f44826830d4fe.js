function Vh() {
this.i=new Wh(this);this.g=0
}