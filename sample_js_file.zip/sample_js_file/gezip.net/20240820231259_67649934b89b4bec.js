function Zm(a) {
var b=S;this.A=b;this.j=a;a=Nm(this.A.document);try{var c=a?Lm(a):null}catch(e){c=null}(a=c)?(c=K(a,Im,5)||null,a=L(a,Hm,7,I()),a=$m(a!=null?a:[]),c={jb:c,mb:a}):c={jb:null,mb:null};a=c;c=an(this,a.mb);a=a.jb;if(a!=null&&ae(a,2)!=null&&O(a,2).length!==0){var d=zd(a,vm,1)?K(a,vm,1):wm();a={uspString:O(a,2),Ga:xm(d)}}else a=null;this.i=a&&c?c.Ga>a.Ga?c.uspString:a.uspString:a?a.uspString:c?c.uspString:null;this.tcString=(c=Mm(b.document))&&ae(c,1)!=null?O(c,1):null;this.g=(b=Mm(b.document))&& 
ae(b,2)!=null?O(b,2):null
}