function i(a) {
return!isNaN(parseFloat(a))&&isFinite(a)
}