function Kc(a) {
var b=typeof a;switch(b){case "bigint":return!0;case "number":return u(Number,"isFinite").call(Number,a)}return b!=="string"?!1:Jc.test(a)
}