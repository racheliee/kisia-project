function Ic(a) {
if(a!=null&&typeof a!=="boolean"){var b=typeof a;throw Error("Expected boolean but got "+(b!="object"?b:a?Array.isArray(a)?"array":b:"null")+": "+a);}return a
}