function nq(a,b,c) {
var d;return Ea(function(e){if(e.g==1){if(!a.j||!c.length||u(a.g.lgdp,"includes").call(a.g.lgdp,Number(b)))return e.return();a.g.lgdp.push(Number(b));d=a.A.performance.now();return wa(e,iq(a),2)}var f=a.i,g=f.na,h=fq(a,d);var k=new sg;k=J(k,1,E(b),0);k=Kd(k,2,c,Mc);h=Ud(h,9,Fg,k);g.call(f,h);e.g=0})
}