function Nh(a,b,c) {
a.j=Ih(1,b,function(){});a.u=function(d,e){return Ih(2,b,function(){return[]})(d,c,e)};a.g=function(){return Ih(3,b,function(){return[]})(c)};a.i=function(d){Ih(16,b,function(){})(d,c)}
}