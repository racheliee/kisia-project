function mq(a) {
var b=Ag(new zg,a.B);hh(a.u,function(){Td(b,2,a.C);je(b,3,a.g.tar);var c=a.i,d=c.na;var e=fq(a);e=Ud(e,8,Fg,b);d.call(c,e)},9)
}