function bk(a,b,c) {
var d;return a.style&&!!a.style[c]&&df(a.style[c])||(d=Xe(a,b))&&!!d[c]&&df(d[c])||null
}