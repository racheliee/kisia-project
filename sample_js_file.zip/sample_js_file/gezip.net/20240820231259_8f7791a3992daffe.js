function g(l) {
return function(p){k||(k=!0,l.call(h,p))}
}