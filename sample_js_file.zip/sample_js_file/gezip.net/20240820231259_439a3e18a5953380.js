function hr() {
var a=S;try{var b=(a||window).document,c=b.compatMode=="CSS1Compat"?b.documentElement:b.body;return(new Ke(c.clientWidth,c.clientHeight)).round()}catch(d){return new Ke(-12245933,-12245933)}
}