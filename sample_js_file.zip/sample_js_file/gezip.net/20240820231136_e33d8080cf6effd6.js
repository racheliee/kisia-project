function t(e,n) {
return new t.fn.init(e,n)
}