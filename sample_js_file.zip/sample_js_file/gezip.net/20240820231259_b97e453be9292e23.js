function id(a) {
return a.xa===$b?a.toJSON():dd(a)
}