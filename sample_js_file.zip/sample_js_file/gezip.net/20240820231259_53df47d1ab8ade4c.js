function Eg(a) {
this.l=F(a)
}