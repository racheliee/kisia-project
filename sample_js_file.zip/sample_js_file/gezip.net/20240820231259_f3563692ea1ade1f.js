function jf() {
var a=R(kf).B(lf.g,lf.defaultValue),b=S.document;if(a.length&&b.head){a=x(a);for(var c=a.next();!c.done;c=a.next())if((c=c.value)&&b.head){var d=We("META");b.head.appendChild(d);d.httpEquiv="origin-trial";d.content=c}}
}