function showSideView(curObj, mb_id, name, email, homepage) {

        var sideView = new SideView('nameContextMenu', curObj, mb_id, name, email, homepage);
        sideView.showLayer();
    
}