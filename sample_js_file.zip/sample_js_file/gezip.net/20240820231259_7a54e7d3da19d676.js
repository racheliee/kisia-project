function kn(a) {
var b=/[a-zA-Z0-9._~-]/,c=/%[89a-zA-Z]./;return a.replace(/(%[a-zA-Z0-9]{2})/g,function(d){if(!d.match(c)){var e=decodeURIComponent(d);if(e.match(b))return e}return d.toUpperCase()})
}