function cq(a,b) {
for(var c=9;c>=0;c--){var d=void 0;(d=a.g.get(c))==null||d.forEach(function(e){e(b)})}
}