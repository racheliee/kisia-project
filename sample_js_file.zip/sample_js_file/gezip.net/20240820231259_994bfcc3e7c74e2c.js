function Lp(a) {
return U(Ki)||a.location&&a.location.hash==="#hffwroe2etoq"
}