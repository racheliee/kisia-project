function uo(a) {
var b={};return{enable_page_level_ads:(b.pltais=!0,b),google_ad_client:a}
}