function am(a,b) {
return t.Promise.race([dm(),em(a,b)])
}