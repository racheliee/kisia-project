function Nq(a) {
R(Lq).g(a)
}