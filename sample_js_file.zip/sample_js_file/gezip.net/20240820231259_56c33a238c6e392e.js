function Ph(a,b) {
b>=0&&b<=1&&(a.g=b)
}