function nb(a) {
rb.pauseOnHover&&sb["mouseenter"===a.type?"pause":"resume"](2)
}