function Zj(a,b) {
var c;c=(c=b.parentElement)?(c=Xe(c,a))?c.direction:"":"";if(c){var d=b.style;d.border=d.borderStyle=d.outline=d.outlineStyle=d.transition="none";d.borderSpacing=d.padding="0";Wj(b,c,"0px");d.width=Oj(a)+"px";if(Yj(a,b,c)!==0){Wj(b,c,"0px");var e=Yj(a,b,c);Wj(b,c,-1*e+"px");a=Yj(a,b,c);a!==0&&a!==e&&Wj(b,c,e/(a-e)*e+"px")}d.zIndex="30"}
}