function Oc(a) {
if(a==null)return a;if(typeof a==="string"){if(!a)return;a=+a}if(typeof a==="number")return u(Number,"isFinite").call(Number,a)?a|0:void 0
}