function uq(a,b) {
try{var c=a.split(".");a=z;for(var d=0,e;a!=null&&d<c.length;d++)e=a,a=a[c[d]],typeof a==="function"&&(a=e[c[d]]());var f=a;if(typeof f===b)return f}catch(g){}
}