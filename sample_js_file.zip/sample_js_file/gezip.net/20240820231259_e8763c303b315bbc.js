function op(a,b) {
var c=a-8-8;--b;return{width:a,height:Math.floor(c/1.91+70)+Math.floor((c*gp.mobile_banner_image_sidebyside+ip.mobile_banner_image_sidebyside)*b+8*b+8)}
}