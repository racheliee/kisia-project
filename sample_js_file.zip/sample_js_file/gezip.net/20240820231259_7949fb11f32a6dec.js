function Hh(a,b,c) {
c.hasOwnProperty(a)||Object.defineProperty(c,String(a),{value:b})
}