function Gf(a,b,c) {
this.url=a;this.A=b;this.ob=!!c;this.depth=null
}