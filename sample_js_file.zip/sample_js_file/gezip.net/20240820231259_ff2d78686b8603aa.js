function pg(a,b) {
try{var c=function(d){var e={};return[(e[d.Pa]=d.Ja,e)]};return JSON.stringify([a.filter(function(d){return d.wa}).map(c),ne(b),a.filter(function(d){return!d.wa}).map(c)])}catch(d){return qg(d,b),""}
}