function tc(a) {
a.xc=!0;return a
}