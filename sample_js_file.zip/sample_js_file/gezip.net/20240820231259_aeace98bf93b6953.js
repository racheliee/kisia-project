function Lb(a) {
return Array.prototype.slice.call(a)
}