function sidebar_read(id) {


	$('#sidebar-response-list').load(sidebar_url + '/response.php?read=1&id=' + id);

	return false;

}