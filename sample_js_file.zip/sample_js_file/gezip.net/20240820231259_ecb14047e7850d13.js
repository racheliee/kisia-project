function apms_like(mb_id, act, id) {

	var href = g5_bbs_url + '/like.php?id=' + mb_id + '&act=' + act;
	$.post(href, { js: "on" }, function(data) {
		if(data.error) {
			alert(data.error);
			return false;
		} else if(data.success) {
			//alert(data.success);
			$("#"+id).text(number_format(String(data.count)));
		}
	}, "json");

}