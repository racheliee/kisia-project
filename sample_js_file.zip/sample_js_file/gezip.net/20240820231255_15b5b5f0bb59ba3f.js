function sidebar_response() {


	var $labels = $('.sidebarLabel');
	var $counts = $('.sidebarCount');
	var url = sidebar_url + '/response.php?count=1';

	$.get(url, function(data) {
		if (data.count > 0) {
			$counts.text(number_format(data.count));
			$labels.show();
		} else {
			$labels.hide();
		}
	}, "json");
	return false;

}