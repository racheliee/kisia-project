function t(e) {
return Math.round(parseFloat(e))
}