function cosmosfarm_members_notifications_subnotify_update(input) {

	var request_url = jQuery('input[name=notifications_request_url]').val();
	var notifications_subnotify_email = jQuery('input[name=notifications_subnotify_email]:checked').val();
	var notifications_subnotify_sms = jQuery('input[name=notifications_subnotify_sms]:checked').val();
	
	if(jQuery(input).data('submitted')){
		alert(cosmosfarm_members_localize_strings.please_wait);
		return false;
	}
	jQuery(input).data('submitted', 'submitted');
	
	jQuery.post(request_url, {action:'cosmosfarm_members_notifications_subnotify_update', notifications_subnotify_email:notifications_subnotify_email, notifications_subnotify_sms:notifications_subnotify_sms, security:cosmosfarm_members_settings.ajax_nonce}, function(res){
		if(res.result == 'success'){
			alert(res.message);
		}
		else{
			alert(res.message);
		}
		jQuery(input).data('submitted', '');
	});
	
	return false;

}