function Ye(e,t) {
return{get:function(){if(!e())return(this.get=t).apply(this,arguments);delete this.get}}
}