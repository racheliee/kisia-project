function cosmosfarm_members_orders_toggle(button, post_id) {

	var parent = jQuery(button).parents('.orders-list-item');
	if(parent.hasClass('item-more-area-hide')){
		parent.removeClass('item-more-area-hide');
	}
	else{
		parent.addClass('item-more-area-hide');
	}
	return false;

}