function L(t,e) {
return parseInt(x.css(t,e),10)||0
}