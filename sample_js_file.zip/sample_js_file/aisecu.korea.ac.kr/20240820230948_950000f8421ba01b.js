function c(a) {
j.length<1&&a.length?a.not("body").blur():j.first().focus()
}