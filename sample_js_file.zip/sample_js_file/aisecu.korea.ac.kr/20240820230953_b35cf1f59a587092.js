function o(n,e,s) {
var i;if(!n)return d;if(typeof n=="string"){var u=n.toLowerCase();z[u]&&(i=u),e&&(z[u]=e,i=u);var h=n.split("-");if(!i&&h.length>1)return o(h[0])}else{var O=n.name;z[O]=n,i=O}return!s&&i&&(d=i),i||!s&&d
}