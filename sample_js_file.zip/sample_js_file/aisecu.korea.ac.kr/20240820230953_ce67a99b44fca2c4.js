function fe(e,t) {
return e.nodeName&&e.nodeName.toLowerCase()===t.toLowerCase()
}