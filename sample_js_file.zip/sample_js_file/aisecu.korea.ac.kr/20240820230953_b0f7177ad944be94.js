function s(e,t) {
this.url=e,this.element=t,this.img=new Image
}