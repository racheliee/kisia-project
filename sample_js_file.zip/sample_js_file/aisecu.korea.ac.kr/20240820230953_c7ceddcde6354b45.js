function Q(e) {
for(var t=0,n=e.length,r="";t<n;t++)r+=e[t].value;return r
}