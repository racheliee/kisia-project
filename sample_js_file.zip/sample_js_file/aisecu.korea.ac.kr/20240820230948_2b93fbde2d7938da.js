function w(a,b) {
this.options=b,this._ns="-modal",this.qtip=a,this.init(a)
}