function A(e,t) {
while((e=e[t])&&1!==e.nodeType);return e
}