function cosmosfarm_members_notifications_toggle(button, post_id) {

	if(jQuery(button).parents('.notifications-list-item').hasClass('item-status-unread')){
		cosmosfarm_members_notifications_read(button, post_id);
	}
	else{
		cosmosfarm_members_notifications_unread(button, post_id);
	}
	
	return false;

}