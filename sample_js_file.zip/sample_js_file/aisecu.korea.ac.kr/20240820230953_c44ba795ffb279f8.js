function B() {
this.expando=ce.expando+B.uid++
}