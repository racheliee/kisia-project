function f(a) {
return a<10?"0"+a:a
}