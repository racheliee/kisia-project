function x(e) {
return e.replace(/-([a-z])/g,function(e,t){return t.toUpperCase()})
}