function W(T) {
var v=a(T).find(".simcal-current"),f=a(T).find(".simcal-events-list-container"),l=f.data("heading-small"),m=f.data("heading-large"),c=a("<h3 />");T.width()<400?c.text(l):c.text(m),v.html(c)
}