function checkWebviewCustomUA(a) {
for(var b=["daum","naver","google","facebook","twitter"],c=!1,d=0,e=b.length;d<e;d++)if(a.indexOf(b[d])>-1){c=!0;break}return c
}