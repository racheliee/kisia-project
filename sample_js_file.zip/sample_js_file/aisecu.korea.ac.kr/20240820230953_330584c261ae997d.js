function cosmosfarm_members_unread_notifications_count_update(count) {

	if(count < 0) count = 0;
	jQuery('.cosmosfarm-members-unread-notifications-count').text(count);
	
	if(count == 0){
		jQuery('.cosmosfarm-members-unread-notifications-count').addClass('display-hide');
	}
	else{
		jQuery('.cosmosfarm-members-unread-notifications-count').removeClass('display-hide');
	}

}