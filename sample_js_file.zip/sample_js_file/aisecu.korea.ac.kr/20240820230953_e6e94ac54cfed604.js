function cosmosfarm_members_messages_subnotify_update(input) {

	var request_url = jQuery('input[name=messages_request_url]').val();
	var messages_subnotify_email = jQuery('input[name=messages_subnotify_email]:checked').val();
	var messages_subnotify_sms = jQuery('input[name=messages_subnotify_sms]:checked').val();
	var messages_subnotify_alimtalk = jQuery('input[name=messages_subnotify_alimtalk]:checked').val();
	
	if(jQuery(input).data('submitted')){
		alert(cosmosfarm_members_localize_strings.please_wait);
		return false;
	}
	jQuery(input).data('submitted', 'submitted');
	
	jQuery.post(request_url, {action:'cosmosfarm_members_messages_subnotify_update', messages_subnotify_email:messages_subnotify_email, messages_subnotify_sms:messages_subnotify_sms, messages_subnotify_alimtalk:messages_subnotify_alimtalk, security:cosmosfarm_members_settings.ajax_nonce}, function(res){
		if(res.result == 'success'){
			alert(res.message);
		}
		else{
			alert(res.message);
		}
		jQuery(input).data('submitted', '');
	});
	
	return false;

}