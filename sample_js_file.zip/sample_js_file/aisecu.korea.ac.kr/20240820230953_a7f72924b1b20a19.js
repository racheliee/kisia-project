function cosmosfarm_members_notifications_delete(button, post_id) {

	var request_url = jQuery('input[name=notifications_request_url]').val();
	
	if(jQuery(button).data('submitted')){
		alert(cosmosfarm_members_localize_strings.please_wait);
		return false;
	}
	
	if(confirm(cosmosfarm_members_localize_strings.are_you_sure_you_want_to_delete)){
		jQuery(button).data('submitted', 'submitted');
		jQuery.post(request_url, {action:'cosmosfarm_members_notifications_delete', post_id:post_id, security:cosmosfarm_members_settings.ajax_nonce}, function(res){
			if(res.result == 'success'){
				jQuery('.notifications-list-item.item-post-id-'+post_id).remove();
				cosmosfarm_members_unread_notifications_count_update(res.unread_count);
			}
			else{
				alert(res.message);
			}
			jQuery(button).data('submitted', '');
		});
	}
	
	return false;

}