function cosmosfarm_members_send_message(args, callback) {

	if(!cosmosfarm_members_ajax_lock){
		cosmosfarm_members_ajax_lock = true;
		jQuery.post(cosmosfarm_members_settings.site_url, {action:'cosmosfarm_members_messages_send', to_user_id:args.to_user_id, title:args.title, content:args.content, security:cosmosfarm_members_settings.ajax_nonce}, function(res){
			cosmosfarm_members_ajax_lock = false;
			if(typeof callback === 'function'){
				callback(res);
			}
			else{
				alert(res.message);
			}
		});
	}
	else{
		alert(cosmosfarm_members_localize_strings.please_wait);
	}
	return false;

}