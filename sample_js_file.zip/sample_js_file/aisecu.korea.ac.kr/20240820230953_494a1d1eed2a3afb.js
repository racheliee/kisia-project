function cosmosfarm_members_add_query_arg(key, value, url) {

	if(url.indexOf('?')>-1){
		url += '&' + key + '=' + value;
	}
	else{
		url += '?' + key + '=' + value;
	}
	return url;

}