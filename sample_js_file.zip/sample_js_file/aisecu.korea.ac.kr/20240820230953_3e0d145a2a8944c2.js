function W(e,t) {
return t.toUpperCase()
}