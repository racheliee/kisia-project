function b(a) {
var b={};return a.replace(/[?&]+([^=&]+)=*([^&]*)/gi,function(a,c,d){b[c]=d}),b
}