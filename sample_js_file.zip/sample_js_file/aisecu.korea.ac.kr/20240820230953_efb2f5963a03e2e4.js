function qe() {
return!1
}