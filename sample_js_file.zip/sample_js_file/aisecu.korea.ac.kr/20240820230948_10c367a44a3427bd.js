function f(a) {
return a===F||"object"!==d.type(a)
}