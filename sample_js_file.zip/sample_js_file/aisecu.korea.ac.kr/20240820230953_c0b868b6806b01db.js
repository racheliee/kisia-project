function o(e) {
this.$L=C(e.locale,null,!0),this.parse(e),this.$x=this.$x||e.x||{},this[H]=!0
}