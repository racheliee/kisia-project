function F(e) {
return e[S]=!0,e
}