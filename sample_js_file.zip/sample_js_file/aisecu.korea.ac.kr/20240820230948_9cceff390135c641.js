function s(t) {
return i.prototype[e].apply(this,t)
}