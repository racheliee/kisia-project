function cosmosfarm_members_notifications_more(button) {

	var request_url = jQuery('input[name=notifications_request_url]').val();
	var paged = jQuery('input[name=notifications_list_page]').val();
	var keyword = jQuery('input[name=notifications_list_keyword]').val();
	var notifications_view = jQuery('input[name=notifications_list_view]').val();
	
	if(paged == -1){
		alert(cosmosfarm_members_localize_strings.no_notifications_found);
		return false;
	}
	
	if(jQuery(button).data('submitted')){
		alert(cosmosfarm_members_localize_strings.please_wait);
		return false;
	}
	jQuery(button).data('submitted', 'submitted');
	
	paged++;
	
	jQuery.post(request_url, {action:'cosmosfarm_members_skin_notifications_list', paged:paged, keyword:keyword, notifications_view:notifications_view, security:cosmosfarm_members_settings.ajax_nonce}, function(res){
		if(!res){
			alert(cosmosfarm_members_localize_strings.no_notifications_found);
			jQuery('input[name=notifications_list_page]').val(-1);
		}
		else{
			jQuery('.notifications-list').append(res);
			jQuery('input[name=notifications_list_page]').val(paged);
		}
		jQuery(button).data('submitted', '');
	}, 'text');
	
	return false;

}