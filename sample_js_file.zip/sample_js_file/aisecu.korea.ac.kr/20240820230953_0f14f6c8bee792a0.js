function Ct(e) {
return e.getAttribute&&e.getAttribute("class")||""
}