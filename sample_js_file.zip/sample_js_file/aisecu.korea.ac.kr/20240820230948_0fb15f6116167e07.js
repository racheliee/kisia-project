function p(a) {
this.rendered&&this.tooltip[0].offsetWidth>0&&this.reposition(a)
}