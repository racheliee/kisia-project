function P() {
C.removeEventListener("DOMContentLoaded",P),ie.removeEventListener("load",P),ce.ready()
}