function x(e) {
return null==e?e+"":"object"==typeof e||"function"==typeof e?n[i.call(e)]||"object":typeof e
}