function s(a) {
return a.charAt(0).toUpperCase()+a.slice(1)
}