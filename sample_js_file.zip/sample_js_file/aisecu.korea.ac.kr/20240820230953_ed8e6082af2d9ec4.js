function M() {
a(".simcal-events-toggle").each(function(T,v){var f=a(v).prev(".simcal-events"),l=f.find(".simcal-event-toggled"),m=a(v).find("i");a(v).on("click",function(){m.toggleClass("simcal-icon-rotate-180"),l.slideToggle()})})
}