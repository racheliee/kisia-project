function ht() {
return ie.setTimeout(function(){st=void 0}),st=Date.now()
}