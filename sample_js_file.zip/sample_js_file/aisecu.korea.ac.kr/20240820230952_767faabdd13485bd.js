function c(a) {
for(var b in a)if(a.hasOwnProperty(b))return!1;return!0
}