function Tt(e) {
return(e.match(D)||[]).join(" ")
}