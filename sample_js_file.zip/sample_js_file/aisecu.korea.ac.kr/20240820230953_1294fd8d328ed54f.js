function cosmosfarm_members_unread_messages_count_update(count) {

	if(count < 0) count = 0;
	jQuery('.cosmosfarm-members-unread-messages-count').text(count);
	
	if(count == 0){
		jQuery('.cosmosfarm-members-unread-messages-count').addClass('display-hide');
	}
	else{
		jQuery('.cosmosfarm-members-unread-messages-count').removeClass('display-hide');
	}

}