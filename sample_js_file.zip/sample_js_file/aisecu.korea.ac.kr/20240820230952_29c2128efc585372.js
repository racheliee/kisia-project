function this_value() {
return this.valueOf()
}