function U(e) {
return e&&"undefined"!=typeof e.getElementsByTagName&&e
}