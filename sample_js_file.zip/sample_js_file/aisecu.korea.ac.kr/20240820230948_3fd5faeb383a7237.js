function k(a) {
return V.concat("").join(a?"-"+a+" ":" ")
}