function f(a,b) {
c.left+=b*a.scrollLeft(),c.top+=b*a.scrollTop()
}