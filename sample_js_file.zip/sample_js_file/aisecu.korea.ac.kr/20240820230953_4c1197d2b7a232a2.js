function Ie(e) {
return e.type=(null!==e.getAttribute("type"))+"/"+e.type,e
}