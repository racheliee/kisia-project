function N(t) {
return null!=t&&t===t.window
}