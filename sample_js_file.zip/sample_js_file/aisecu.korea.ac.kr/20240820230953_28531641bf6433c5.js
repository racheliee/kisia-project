function kt(e) {
return Array.isArray(e)?e:"string"==typeof e&&e.match(D)||[]
}