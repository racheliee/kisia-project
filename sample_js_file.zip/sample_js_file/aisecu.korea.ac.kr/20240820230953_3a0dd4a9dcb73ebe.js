function t(e) {
var t=i.createElement("script");t.src=e,t.defer=!0,i.head.appendChild(t)
}