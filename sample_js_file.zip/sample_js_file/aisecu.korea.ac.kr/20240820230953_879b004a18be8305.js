function o(n,e) {
if(n.date()<e.date())return-o(e,n);var s=12*(e.year()-n.year())+(e.month()-n.month()),i=n.clone().add(s,f),u=e-i<0,h=n.clone().add(s+(u?-1:1),f);return+(-(s+(e-i)/(u?i-h:h-i))||0)
}