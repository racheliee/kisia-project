function r(e) {
this.img=e
}