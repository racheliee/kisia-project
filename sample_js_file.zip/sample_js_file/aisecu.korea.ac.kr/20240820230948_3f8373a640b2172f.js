function o() {
return i.prototype[e].apply(this,arguments)
}