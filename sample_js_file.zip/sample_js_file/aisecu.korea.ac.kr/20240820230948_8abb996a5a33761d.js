function u(a,b) {
return Math.ceil(parseFloat(t(a,b)))
}