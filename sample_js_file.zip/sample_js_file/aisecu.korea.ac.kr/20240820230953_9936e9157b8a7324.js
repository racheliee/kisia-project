function Ne() {
return!0
}