function cosmosfarm_members_messages_toggle(button, post_id) {

	if(jQuery(button).parents('.messages-list-item').hasClass('item-status-unread')){
		cosmosfarm_members_messages_read(button, post_id);
	}
	else{
		cosmosfarm_members_messages_unread(button, post_id);
	}
	
	return false;

}