function x(a) {
this._ns="ie6",this.qtip=a,this.init(a)
}