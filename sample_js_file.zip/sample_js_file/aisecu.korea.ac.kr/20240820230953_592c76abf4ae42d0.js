function refined_magazine_search(e) {

        $('.top-bar-search').addClass('open');
        $('.top-bar-search form input[type="search"]').focus();
        var focusableEls = $('.top-bar-search a[href]:not([disabled]), .top-bar-search button:not([disabled]), .top-bar-search input:not([disabled])');
        var firstFocusableEl = focusableEls[0];
        var lastFocusableEl = focusableEls[focusableEls.length - 1];
        var KEYCODE_TAB = 9;
        $('.top-bar-search').on('keydown', function (e) {
            if (e.key === 'Tab' || e.keyCode === KEYCODE_TAB) {
                if (e.shiftKey) /* shift + tab */ {
                    if (document.activeElement === firstFocusableEl) {
                        lastFocusableEl.focus();
                        e.preventDefault();
                    }
                } else /* tab */ {
                    if (document.activeElement === lastFocusableEl) {
                        firstFocusableEl.focus();
                        e.preventDefault();
                    }
                }
            }
        });
    
}