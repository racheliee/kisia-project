function c(e,t,r,n,o) {
if(!o)throw new Error("No warning message provided");return a(e,t,r,n,o),0
}