function i(e,t) {
for(var i in t)e[i]=t[i];return e
}