function _(t) {
return function(e){return(fe(e,"input")||fe(e,"button"))&&e.type===t}
}