function l(a,b) {
return b>0?setTimeout(d.proxy(a,this),b):void a.call(this)
}