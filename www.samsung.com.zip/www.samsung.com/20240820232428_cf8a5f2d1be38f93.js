function t(e) {
return"function"==typeof e
}