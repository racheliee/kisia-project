function i(e) {
f&&r({requestId:e.requestId,timestamp:q()})
}