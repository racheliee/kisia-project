function zn(e) {
if(!e.nameSpaces&&!e.dataSources)return Gn(e,Mm);var t=[];return e.nameSpaces&&t.push.apply(t,Gn(e.nameSpaces,Rm)),e.dataSources&&t.push.apply(t,Gn(e.dataSources,Mm)),t
}