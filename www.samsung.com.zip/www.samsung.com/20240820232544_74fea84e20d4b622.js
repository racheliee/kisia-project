function qd(e,t) {
if(ke()[jh]){if(!x(e)||N(e))return We(Gb,tv,e),void et({source:Gb,view:e,error:tv});var n=e.toLowerCase(),a=Fd(n,t);Qe(Gb,n,a),Ue()?an(a):(et({source:Gb,view:n,options:a}),Bd(a))}else We(Gb,nv)
}