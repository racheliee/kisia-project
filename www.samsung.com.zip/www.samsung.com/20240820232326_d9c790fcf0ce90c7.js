function J() {
var aB="";try{if(Y()&&!G()&&document.body){var aD=document.body.addBehavior("#default#clientCaps");if(document.body.connectionType){aB=document.body.connectionType}document.body.removeBehavior(aD)}}catch(aC){}Q.ct=aB
}