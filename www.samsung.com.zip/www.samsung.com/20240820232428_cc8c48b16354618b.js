function Tt(e,t) {
return Tt=Object.setPrototypeOf?Object.setPrototypeOf.bind():function(e,t){return e.__proto__=t,e},Tt(e,t)
}