function Sa(e) {
if(!m(e))return{};var t=null;try{t=e()}catch(e){return{}}return p(t)?{}:lu(t)?Pa(t):x(t)&&wu(t)?xa(t):v(t)?$a(t):{}
}