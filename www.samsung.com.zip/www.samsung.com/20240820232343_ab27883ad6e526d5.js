function n() {
s++,s==r&&i()
}