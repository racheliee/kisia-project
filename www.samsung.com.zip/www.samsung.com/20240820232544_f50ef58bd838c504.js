function ht(e,t) {
if(!pt(e))return!0;var n=e[iv][sv],a=(e[iv][sv][lv]||{})[t];return n[ov](a)
}