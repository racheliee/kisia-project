function ts(e,t) {
e.parameters=t.parameters,e.profileParameters=t.profileParameters,e.order=t.order,e.product=t.product
}