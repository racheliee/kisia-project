function logger(gb) {
if(gb==="oper"){window["console"]["log"]=function(){};window["console"]["debug"]=function(){}}
}