function a(e,t) {
return Object.prototype.hasOwnProperty.call(Object(e),t)
}