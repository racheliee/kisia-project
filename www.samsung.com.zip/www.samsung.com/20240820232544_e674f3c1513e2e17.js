function Sn(e,t) {
return Pn(Sm,t+" {"+e+"}")
}