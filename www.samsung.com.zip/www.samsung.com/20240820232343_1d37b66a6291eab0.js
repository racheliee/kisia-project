function getBrowserScheme() {

	let browserName = "";
	try {
        let agent = window.navigator.userAgent.toLowerCase();
        switch (true) {
            case agent.indexOf("kakaotalk") > -1:
                browserName = "";
                break;
            case agent.indexOf("naver") > -1:
                browserName = "com.nhn.android.search";
                break;
            case agent.indexOf("samsungbrowser") > -1:
                browserName = "com.sec.android.app.sbrowser";
                break;
            case agent.indexOf("whale") > -1:
                browserName = "com.naver.whale";
                break;
            case agent.indexOf("firefox") > -1:
                browserName = "org.mozilla.firefox";
                break;
            case agent.indexOf("edga") > -1:
                browserName = "com.microsoft.emmx";
                break;
            case agent.indexOf("edge") > -1:
                browserName = "com.microsoft.emmx";
                break;
            case agent.indexOf("opr") > -1:
                browserName = "com.opera.browser";
                break;
            case agent.indexOf("chrome") > -1:
                browserName = "com.android.chrome";
                break;
            case agent.indexOf("safari") > -1:
                browserName = "savannah.internet.web.browser";
                break;
            default:
                browserName = "";
        }
        return browserName;
    } catch (exception) {
    	return browserName;
    }

}