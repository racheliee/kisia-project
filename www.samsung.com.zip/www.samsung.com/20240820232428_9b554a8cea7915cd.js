function vt(e) {
if(!f(e))throw new Error("elements should be an Array");return function(t){return e.indexOf(t)>-1}
}