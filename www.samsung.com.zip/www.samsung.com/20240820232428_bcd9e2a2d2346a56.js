function re(e) {
return"number"==typeof e&&e>-1&&e%1==0&&e<=9007199254740991
}