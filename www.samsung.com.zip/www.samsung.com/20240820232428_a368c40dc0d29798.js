function se(e) {
return d(e)&&"[object Arguments]"==p(e)
}