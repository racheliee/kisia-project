function mask(action, data, element) {

    const elem = element || null;
    
    if(action == 'close') { // hide
      innerMask.style.display = 'none';
      outerMask.style.display = 'none';
      innerMask.dataset.type = data;
      outerMask.dataset.type = data;
      screenLock("unlock");
    }else{ // show
      if (device.val == "m" || device.val == "t" || window.innerWidth < 1280) { // m, t size
        handleMask(data);
        screenLock("lock");
      } else { // p size
        if (elem == null) {
          // element 미지정시(null) mask on / data type 삽입
          outerMask.style.display = "block";
          outerMask.dataset.type = data;
        } else if (elem.children.length <= 1) {
          // element 는 있으나 하위자식이 없으면 mask off
          outerMask.style.display = "none";
          screenLock("unlock");
          return;
        } else {
          // element 가 있고 하위자식도 있으면 mask on :
          outerMask.style.display = "block";
          // outerMask.dataset.type = data;
        }
      }
    }
    
    function handleMask(data) {
      // console.log("thisdata : " + data);

      if (data == "cart" || data == 'location') {
        outerMask.style.display = "block";
        outerMask.dataset.type = data;
      } else {
        innerMask.style.display = "block";
        innerMask.dataset.type = data;
      }
      screenLock("lock");
    }

    function screenLock(action){
      if(action == 'lock'){
        $("html, body").css({
          height: 100 + "%",
          overflow: "hidden",
        });
      }else{
        $("html, body").css({
          height: "auto",
          overflow: "unset",
        });
      }
    }
  
}