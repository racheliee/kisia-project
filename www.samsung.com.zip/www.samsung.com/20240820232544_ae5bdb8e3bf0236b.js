function ti(e) {
return!!ei(e)&&wu(e.eventToken)
}