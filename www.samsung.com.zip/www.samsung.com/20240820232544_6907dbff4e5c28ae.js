function aa() {
var e=na(),t=ke();return Xn(e,t[fh],t[mh])
}