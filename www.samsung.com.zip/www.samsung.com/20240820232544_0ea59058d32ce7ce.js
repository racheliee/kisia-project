function e(e) {
if(null==e)throw new TypeError("Object.assign cannot be called with null or undefined");return Object(e)
}