function location() {

    console.log("location active!");
  
}