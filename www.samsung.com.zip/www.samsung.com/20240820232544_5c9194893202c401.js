function Ed(e) {
var t=e[Qu],n=e[ap];return wu(t)&&(wu(n)||qt(n))
}