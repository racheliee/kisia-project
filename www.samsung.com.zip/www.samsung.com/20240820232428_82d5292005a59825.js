function Ae(e,t) {
var n=f(e),r=!n&&fe(e),o=!n&&!r&&ge(e),i=!n&&!r&&!o&&Oe(e),a=n||r||o||i,c=a?function(e,t){for(var n=-1,r=Array(e);++n<e;)r[n]=t(n);return r}(e.length,String):[],s=c.length;for(var u in e)!t&&!je.call(e,u)||a&&("length"==u||o&&("offset"==u||"parent"==u)||i&&("buffer"==u||"byteLength"==u||"byteOffset"==u)||V(u,s))||c.push(u);return c
}