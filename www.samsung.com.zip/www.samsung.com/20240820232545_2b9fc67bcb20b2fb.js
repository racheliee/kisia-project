function getProductCompareHtml(obj) {

            var prd               = $(obj).data();
            var prdLink           = prd.goodsPath;
            var useCompareYn      = prd.useCompareYn;
            var cptLytNo          = $(obj).data("cptlytno");
            var compareShowRdoBtn = $(obj).data("compare-show-rdo-btn");
            var reviewShowRdoBtn  = $(obj).data("review-show-rdo-btn");
            var liItem = "";
            var contextPath = "/sec/";
            
            if(cptLytNo == "44"){
                liItem += '<div>';
            }
            if (compareShowRdoBtn != "002"){
                if (useCompareYn == 'Y') {
                    if((prd.compareExcptYn == null || prd.compareExcptYn == 'N') && prd.intgrSpecYn == 'Y'){
                        var compareHtml = productCompareView(prd);
                        if(cptLytNo == "44"){
                            liItem += '<div class="compare">' + compareHtml + '</div>';
                        } else {
                            liItem += compareHtml;
                        }
                    }
                }
            }
            if(cptLytNo == "44"){
                liItem += '</div>';
            }
            
            // 패넷은 상품평 노출 제외
            // 임직원몰(기획전몰)_체험단말 노출 제외 추가 2020-12-03
            // 임직원몰(기획전몰)_갤럭시캠퍼스 노출 제외 추가 2020-12-29
            //2022.05.30 갤캠스 노출 제외 삭제
            //2023.08.30 홈클래스 VOD 상품 상품평 노출 제외
            if (reviewShowRdoBtn != "002"){
                var isCommentGrade = false;
                if (('Y' == 'Y' || stGbCd == '70' ||
                     stGbCd == '80' && !(contextPath.indexOf("ma_24") > -1 ||
                                         contextPath.indexOf("24_pa") > -1 ||
                                         contextPath.indexOf("24_mx") > -1 ||
                                         contextPath.indexOf("fan_24") > -1)
                ) && prd.isHomefitnessGoodsYn != 'Y' && prd.homeClsGoodsYn != 'Y')
                {
                    isCommentGrade = true;
                } 
                // B2B  소상공인몰만 상품평 별점 노출
                if(location.href.indexOf('business/soho') >= 0){
                    isCommentGrade = true;
                }
                if(isCommentGrade) {
                    if(cptLytNo == "44"){
                        liItem += '<div>'; 
                        liItem += '      <a class="rvpd-star" target="_blank" href="' + prdLink + '?focus=review" title="상품평점" data-review-grade="' + prd.reviewGrade + '" data-review-count="' + prd.reviewCount + '">';
                        liItem += '          <strong>' + prd.reviewGrade + '</strong>' + ' (' + prd.reviewCount + ')';
                        liItem += '      </a>';
                        liItem += '</div>';
                    } else {
                        liItem += '      <a class="link-review" target="_blank" href="' + prdLink + '?focus=review" title="상품평점" data-review-grade="' + prd.reviewGrade + '" data-review-count="' + prd.reviewCount + '">';
                        liItem += '          <span>' + prd.reviewGrade + '</span>' + ' (' + prd.reviewCount + ')';
                        liItem += '      </a>';
                    }
                } else {
                    if(cptLytNo == "44"){
                        liItem += '<div>'; 
                        liItem += '</div>';
                    }
                }
            }
            
            var cardCompareHtml = "";
            if(liItem.length > 0){
                if(cptLytNo == "12" || cptLytNo == "45"){
                    cardCompareHtml += '<div class="card-purchase" name="cardCompare">';
                    cardCompareHtml +=     '<div class="box-compare">';
                    cardCompareHtml +=         liItem;
                    cardCompareHtml +=     '</div>';
                    cardCompareHtml += '</div>';
                } else if(cptLytNo == "44"){
                    cardCompareHtml += '<div class="rvpd-bottom" name="cardCompare">';
                    cardCompareHtml +=     liItem;
                    cardCompareHtml += '</div>';
                } else {
                    cardCompareHtml += '<div class="card-purchase" name="cardCompare">';
                    cardCompareHtml +=     '<div class="card-compare">';
                    cardCompareHtml +=         liItem;
                    cardCompareHtml +=     '</div>';
                    cardCompareHtml += '</div>';
                }
                $(obj).siblings("[name=cardCompare]").remove();
                $(obj).after(cardCompareHtml);
            }
        
}