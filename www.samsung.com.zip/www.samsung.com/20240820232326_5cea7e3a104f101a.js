function o() {
Q.j="";try{Q.j=navigator.javaEnabled()?"Y":"N"}catch(aB){}
}