function pauseKV() {

        $('.carousel-container .slide-pause').click();
    
}