function It(e,t,n,a) {
var r=new e.CustomEvent(n,{detail:a});t.dispatchEvent(r)
}