function p() {
function e(e){0!==e.indexOf("_")&&"function"==typeof n[e]&&(f[e]=function(){})}Object.keys(n).forEach(e),f.getSupplementalDataID=n.getSupplementalDataID,f.isAllowed=function(){return!0}
}