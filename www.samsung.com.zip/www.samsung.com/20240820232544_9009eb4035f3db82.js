function ni(e) {
return!D(e)&&!N(e.type)&&wu(e.eventToken)
}