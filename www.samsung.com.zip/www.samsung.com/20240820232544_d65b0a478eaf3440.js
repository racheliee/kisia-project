function Ai(e) {
if(!Ii(e))return null;var t=Ei(e);return x(t[Ku])?t:(Qe(hf,t),null)
}