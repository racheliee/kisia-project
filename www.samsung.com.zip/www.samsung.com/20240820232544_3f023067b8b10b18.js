function n(e) {
return function(n,a){if(!ge(n))throw new Error("[OptIn] Invalid category(-ies). Please use the `OptIn.Categories` enum.");return T(te.CHANGED),Object.assign(w,be(ve(n),e)),a||t(),v}
}