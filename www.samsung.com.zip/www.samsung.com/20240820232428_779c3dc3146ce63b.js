function N(e,n,r,o) {
var i=t(r),a=void 0,c=void 0,s=!0;if(i){try{a=r(o)}catch(e){s=!1,c=e}if(n===a)return void z(n,P())}else a=o;n._state!==A||(i&&s?R(n,a):!1===s?z(n,c):e===T?M(n,a):e===C&&z(n,a))
}