function a(e,t,n) {
var a=null==e?void 0:e[t];return void 0===a?n:a
}