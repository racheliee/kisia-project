function w(e) {
if("number"==typeof e)return e;if(function(e){return"symbol"==typeof e||d(e)&&"[object Symbol]"==p(e)}(e))return NaN;if(g(e)){var t="function"==typeof e.valueOf?e.valueOf():e;e=g(t)?t+"":t}if("string"!=typeof e)return 0===e?e:+e;e=v(e);var n=b.test(e);return n||_.test(e)?k(e.slice(2),n?2:8):y.test(e)?NaN:+e
}