function or() {
return U((function(e,t,n){return Ja(n)||(e[n]=p(t)?"":t),e}),{},arguments.length>0&&void 0!==arguments[0]?arguments[0]:{})
}