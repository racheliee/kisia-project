function ge(e,t,n) {
var a="";e.location.protocol===Iv||(a=me(e.location.hostname)),n[Vh]=a,n[Jf]=he(t)&&fe(t),pe(n,e[Ah]||{})
}