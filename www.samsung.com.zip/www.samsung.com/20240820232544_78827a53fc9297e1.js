function Qd() {
Object.keys(localStorage).filter(nk).forEach((function(e){return localStorage.removeItem(e)}))
}