function ai(e) {
return!!ni(e)&&wu(e.selector)
}