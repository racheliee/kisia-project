function Tr() {
var e=Sv.documentElement;return{width:e.clientWidth,height:e.clientHeight}
}