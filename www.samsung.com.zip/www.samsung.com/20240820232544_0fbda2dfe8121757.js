function hc(e,t) {
e===qp&&As(Yf,t)
}