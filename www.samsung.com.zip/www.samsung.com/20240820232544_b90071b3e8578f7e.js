function de(e) {
var t=e();return t[6]=15&t[6]|64,t[8]=63&t[8]|128,le(t)
}