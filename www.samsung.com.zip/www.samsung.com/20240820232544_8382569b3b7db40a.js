function So(e) {
var t=zt(e[ap]),n=e[Ku];return n[Ju]=oo(n[Ju]),n[Xu]=oo(n[Xu]),Qe(ff,e),et({action:e}),Ds(n,t),ot(e)
}