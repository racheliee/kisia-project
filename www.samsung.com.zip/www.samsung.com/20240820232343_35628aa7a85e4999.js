function e(e) {
return null!==e&&"object"==typeof e&&"constructor"in e&&e.constructor===Object
}