function t(e) {
r.addEventListener("load",(function(){r.className="aamIframeLoaded",a.iframeHasLoaded=!0,a.fireIframeLoadedCallbacks(e),a.requestToProcess()}))
}