function setPopSlickDataOmni(el,cptEnNm) {
setTimeout(function(){setSlickDataOmni(el,cptEnNm,"POP")},100)
}