function x(e) {
var t=function(e){return e?(e=w(e))===S||e===-1/0?17976931348623157e292*(e<0?-1:1):e==e?e:0:0===e?e:0}(e),n=t%1;return t==t?n?t-n:t:0
}