function Dl(e) {
return wu(e)||qt(e)?e:Up
}