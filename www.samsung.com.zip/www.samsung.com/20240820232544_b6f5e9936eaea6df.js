function ar(e) {
return e[ig]
}