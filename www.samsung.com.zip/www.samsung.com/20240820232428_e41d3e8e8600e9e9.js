function c(e) {
i=e
}