function n(t,e) {
t&&(this.element=t,this.layout=e,this.position={x:0,y:0},this._create())
}