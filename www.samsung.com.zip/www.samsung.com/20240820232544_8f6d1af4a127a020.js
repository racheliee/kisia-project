function Ld(e) {
var t=td(e),n=t[Ef];if(!t[Af])return We(Hb,n),void et({source:Hb,options:e,error:n});var a=Sd(ke(),e);if(!Be())return We(Hb,Kp),z(a[Ef](If,Kp)),void et({source:Hb,options:e,error:Kp});Qe(Hb,a),et({source:Hb,options:a}),Ed(a)?Dd(a):Od(a)
}