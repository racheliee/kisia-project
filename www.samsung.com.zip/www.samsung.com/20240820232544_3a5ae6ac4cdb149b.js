function pc(e) {
var t=e.viewName,n=e.impressionId,a=Aa(ke()[rh]),r=rc(Fr({},a),Zh,[]);r.view={name:t},Qe(db,t),ac(t,a,[r]).then((function(e){e.impressionId=n,et({view:t,event:bb,request:e}),oc(e)}))
}