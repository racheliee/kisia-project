function p(e) {
return u()?ru.default(e,{telemetry:{entries:d()}}):e
}