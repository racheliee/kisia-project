function to(e) {
return U((function(e,t){return e.then((function(){return Qe(Sf,t),et({remoteScript:t}),cu.default(t)}))}),ot(),e)
}