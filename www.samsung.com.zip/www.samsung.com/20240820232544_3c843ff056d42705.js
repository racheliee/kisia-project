function q(e,t) {
for(var n=0;n<t.length;n+=1)if(!F(e[t[n]]))return e[t[n]]
}