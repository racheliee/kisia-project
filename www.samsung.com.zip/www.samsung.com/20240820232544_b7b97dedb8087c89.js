function L(e) {
return p(e)?"":Cu.call(e)
}