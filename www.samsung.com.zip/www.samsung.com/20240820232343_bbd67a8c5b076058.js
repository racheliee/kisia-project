function n() {
return i.prototype[e].apply(this,arguments)
}