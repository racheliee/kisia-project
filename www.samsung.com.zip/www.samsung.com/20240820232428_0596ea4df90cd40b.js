function ft(e,t,n) {
e.addEventListener&&e.addEventListener(t,n,!1)
}