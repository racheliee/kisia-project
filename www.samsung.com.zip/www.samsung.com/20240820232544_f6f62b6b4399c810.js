function As(e,t) {
return zt(t).addClass(e)
}