function Jo(e,t,n) {
var a={};a[Yh]=[Jh];var r={};r[Hg]=Ug,r[Gg]=t,r[Wg]=n,r[Qg]=!0,r[Zg]=!1,r[zg]=a;try{e(r)}catch(e){return!1}return!0
}