function ss(e) {
var t=e.response.execute;if(!v(t))return ot(null);var n=t.pageLoad;if(!v(n))return ot(null);var a=n.analytics,r=n.options,i=n.metrics,s=D(a)?{}:{analytics:a};return dt([rs(r,ei),is(i,ai)]).then((function(e){return ns(s,e)}))
}