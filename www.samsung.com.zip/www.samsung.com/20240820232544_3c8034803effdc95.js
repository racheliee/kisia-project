function Zl(e) {
if(!v(e))return Ql(Yp);var t=Kl(e[jf]);return t[Af]?m(e[Df])?m(e[Ef])?Wl():Ql(of):Ql(sf):t
}