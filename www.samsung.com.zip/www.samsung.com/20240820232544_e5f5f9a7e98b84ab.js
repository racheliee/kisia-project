function oa(e) {
return Kn(na(),e)
}