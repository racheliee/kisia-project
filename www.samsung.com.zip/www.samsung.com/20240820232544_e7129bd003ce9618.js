function a(e,i) {
try{if(i&&("object"==typeof i||"function"==typeof i)){var o=i.then;if("function"==typeof o)return void o.call(i,(function(t){a(e,t)}),n)}r[e]=i,0==--s&&t(r)}catch(e){n(e)}
}