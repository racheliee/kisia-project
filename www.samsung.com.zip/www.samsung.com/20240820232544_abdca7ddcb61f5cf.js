function Pt() {
if(!ke()[hh])return"";var e=Fv(xh);return N(e)?"":e
}