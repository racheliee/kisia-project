function a(e) {
return null!=e&&e==e.window
}