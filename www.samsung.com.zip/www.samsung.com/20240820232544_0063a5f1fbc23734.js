function m(e,t) {
var n,a=e?e.length:0;for(n=0;n<a;n++)this[n]=e[n];this.length=a,this.selector=t||""
}