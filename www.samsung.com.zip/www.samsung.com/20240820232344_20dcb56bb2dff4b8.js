function cartDirect(mdlCode) {
var mdlList=[];var mdl={};mdl.mdlCode=mdlCode;mdl.qty=1;mdlList.push(mdl);fnCartDirect(mdlList,"confirm")
}