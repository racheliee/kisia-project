function Yt(e) {
return zt(e).next()
}