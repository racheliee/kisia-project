function fn(e) {
var t=_e(e),n=t[gm];if(N(n))return null;var a={};a.token=n;var r=t[km];wu(r)&&r===Op&&(a.listedActivitiesOnly=!0);var i=t[_m];wu(i)&&(a.evaluateAsTrueAudienceIds=ln(i));var s=t[Vm];wu(s)&&(a.evaluateAsFalseAudienceIds=ln(s));var o=t[bm];return D(o)||(a.previewIndexes=pn(o)),a
}