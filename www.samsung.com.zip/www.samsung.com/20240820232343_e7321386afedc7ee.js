function GA4ShareFollow(socialNetwork) {

		try {
			window.dataLayer = window.dataLayer || [];
			window.dataLayer.push({
				event: 'share_follow',
				social_network: socialNetwork
			});
		} catch (e) {
			// 예외 처리를 위한 삼성의 코드
		}
	
}