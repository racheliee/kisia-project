function xt(e) {
if(N(e))return"";var t=Zv.exec(e);return D(t)||2!==t.length?"":t[1]
}