function pr(e) {
return w((function(t,n){lu(t)&&w((function(t){e.setRequestHeader(n,t)}),t)}),arguments.length>1&&void 0!==arguments[1]?arguments[1]:{}),e
}