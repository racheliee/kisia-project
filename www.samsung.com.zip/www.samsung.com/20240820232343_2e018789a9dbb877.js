function getDispPathByUrl() {

				
				let stId   = "1";
				let reqUri = "/sec/";
				reqUri = reqUri.replace("/sec/", "");
				if (reqUri.length == 0) return;
		    	
				let tmp = "";
				
				if("" === "Y") return;
				
				if(reqUri.indexOf('homefitness') > -1) {
					return;
				}
				
				$.ajax({
					url     : "/sec/cxhr/display/getGnbByUrl"
				  , type    : "GET"
			      , data    : {stId:stId, linkUrl:reqUri}
				  , success : function(data) {
				        list = data.list;
						if (list == null) return;
		   				
						$.each(list, function(idx, obj) {
							if (obj.linkUrl.length > 0) {
		   						tmp += '<a href="/sec/'+obj.linkUrl+'">'+obj.dispClsfNm+'</a>';
							} else if(obj.dispClsfNm != obj.upDispClsfNm){	//동일명칭 Depth Skip 2020.09.14 YJU
		   						tmp += "<span>"+obj.dispClsfNm+"</span>";
		   					}
		   				});
		   				
						if (tmp == '') return;
						let html = "";
						html += "<div class=\"pg-location-inner locationDiv\">";
						html += "<a href='/sec/'>HOME</a>";
						html += tmp;
						html += "</div>";
						$(".pg-location").html(html);
					}
				});
			
}