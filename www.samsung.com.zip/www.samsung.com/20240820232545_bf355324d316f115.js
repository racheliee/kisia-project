function fontInit() {
defsize=15;objs=$(".layer-pop *");$(objs).css("font-size",defsize+"px")
}