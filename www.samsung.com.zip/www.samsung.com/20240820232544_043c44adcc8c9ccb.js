function Ot(e,t) {
var n=t.mbox,a=t.error,r=t.url,i=t.analyticsDetails,s=t.responseTokens,o=t.execution,c={type:e,tracking:Et(Ct,Tt)};return p(n)||(c.mbox=n),p(a)||(c.error=a),p(r)||(c.url=r),D(i)||(c.analyticsDetails=i),D(s)||(c.responseTokens=s),D(o)||(c.execution=o),c
}