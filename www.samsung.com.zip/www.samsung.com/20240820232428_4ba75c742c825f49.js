function mn(e,t,n) {
var r=hn[t];return r&&r.close&&!r.closed&&r.close(),hn[t]=window.open(e,t,n),hn[t]
}