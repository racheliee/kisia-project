function closeMarketingPop() {

		popupList.forEach(function(popup, idx) {
			if(popup.rptYn === "N"){
				// 반복 없음 [1회성]
				setRptNCookie(popup);
			} else {
				// 기간 내 반복 노출 [일주일 그만보기]
				let stopView = $("#marketingPop #chk-not-see-week").is(":checked");
				if(stopView === true) {
					setCookieMarketingPop(popup);
				}
			}
		});

		$("#marketingPop").removeClass("active");
		$("#mask").fadeIn("fast").remove();
		$('body').css('overflow-y','visible');
	
}