function rc(e,t,n) {
var a={id:ue(),type:t,timestamp:q(),parameters:e.parameters,profileParameters:e.profileParameters,order:e.order,product:e.product};return D(n)||(a.tokens=n),a
}