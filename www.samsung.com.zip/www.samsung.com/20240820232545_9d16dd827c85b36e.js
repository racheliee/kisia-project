function hideEndToast() {

            var screen_size = $(window).width();
            var pfpdCompare= $('.pfpd-compare'); 
    
            if(screen_size <= 800){
                if(!($(document).scrollTop() > $("#footer").offset().top)) {
                    if($("#pfpdSlideCompare .prd div.box").not(".compare-emptyBox").length > 0){  // 비교하기 상품이 있는 경우만 show
                        if(pfpdCompare.hasClass('open')){
                            pfpdCompare.show({ 
                                effect : "slide", 
                                direction : "down"
                            });
                        }else{
                            pfpdCompare.show({ 
                                effect : "slide", 
                                direction : "down"
                            }); 
                        }
                    }
                }else{
                    pfpdCompare.hide({ 
                        effect : "slide",
                        direction : "down"
                    });
                }
            }
        
}