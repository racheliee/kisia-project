function X(e) {
return!!e.prefetch&&!!e.prefetch.mboxes&&e.prefetch.mboxes.length||0
}