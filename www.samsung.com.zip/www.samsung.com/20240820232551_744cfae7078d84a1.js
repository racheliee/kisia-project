function c() {
clearTimeout(d),d=setTimeout(b,e)
}