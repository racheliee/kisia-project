function Be() {
return ke()[Jf]&&Me()&&!Fe()
}