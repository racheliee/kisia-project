function ci(e) {
var t=e.response,n=t.execute,a=void 0===n?{}:n,r=t.prefetch,i=void 0===r?{}:r,s=t.notifications,o=void 0===s?{}:s,c=a.pageLoad,l=void 0===c?{}:c,d=a.mboxes,u=void 0===d?[]:d,p=i.mboxes,f=void 0===p?[]:p,h=i.views,v=void 0===h?[]:h;return oi(l),w(oi,u),w(oi,f),w(oi,v),w(oi,o),e
}