function n(r) {
var o=r.data,i=r.origin;if(o&&i===t){var a=JSON.parse(o);a.code?e.fail(a):e.success(a),e.always(a),ht(window,"message",n)}
}