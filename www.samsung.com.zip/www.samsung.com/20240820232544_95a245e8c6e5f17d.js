function Kd(e,t) {
try{localStorage.setItem(e,JSON.stringify(t))}catch(e){Qd()}
}