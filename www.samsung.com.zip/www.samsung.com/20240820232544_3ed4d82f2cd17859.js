function da(e) {
var t=e[Ah];if(p(t))return!1;var n=t[Lh];return!(!lu(n)||D(n))
}