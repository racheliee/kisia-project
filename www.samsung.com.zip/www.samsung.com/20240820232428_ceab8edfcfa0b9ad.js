function writableCommentSetC() {

    var wcpc = $("#chknotsee").is(":checked");
    setCookieA("commentPopYN","N",wcpc ? 7 : 1);
    closeLayer("popupInduceReview");
    setCookieA("commentPC","N",1);
    setTimeout(function(){$("#popupInduceReview").remove()},1000);

}