function uc(e,t,n) {
var a=Aa(ke()[rh]),r=rc(Fr({},a),t,[n]);r.view={name:e};var i=nc(ue(),a,[r]);Qe(vb,e,r),et({view:e,event:t,request:i}),oc(i)
}