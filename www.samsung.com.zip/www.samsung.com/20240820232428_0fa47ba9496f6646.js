function V(e,t) {
var n=typeof e;return!!(t=null==t?9007199254740991:t)&&("number"==n||"symbol"!=n&&G.test(e))&&e>-1&&e%1==0&&e<t
}