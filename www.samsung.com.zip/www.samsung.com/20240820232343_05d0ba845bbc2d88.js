function v(t) {
return!e.cssMode||t!==l.length-1
}