function i() {
var t=n(e);D(t)?z(i,nb):a(t)
}