function dn(e) {
var t=G(ym,e),n=cn(t[0]);if(p(n))return null;var a={};a.activityIndex=n;var r=cn(t[1]);return p(r)||(a.experienceIndex=r),a
}