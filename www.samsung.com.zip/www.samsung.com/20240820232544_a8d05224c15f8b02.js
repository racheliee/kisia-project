function Vr() {
return[ra(),ka()]
}