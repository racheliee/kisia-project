function gi(e,t,n) {
return e.onload=function(){var a=1223===e.status?204:e.status;if(a<100||a>599)n(new Error(Mg));else{var r=e.responseText,i=e.getAllResponseHeaders();t({status:a,headers:i,response:r})}},e
}