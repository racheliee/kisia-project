function appWebAutoLogin2() {

    try {
    	if($("#appWebMask").html() == undefined){
    		// skip
    	} else {
    		appWebAutoLogin();
    	}
    } catch (exception) {
        //console.log(exception);
    }

}