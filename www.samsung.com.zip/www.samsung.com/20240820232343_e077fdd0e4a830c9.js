function NetFunnel_Action_pdView(url) {

        NetFunnel_Action({action_id :'b2c_pd_view'},function(ev, ret){
        	window.location.href = url;
		});
    
}