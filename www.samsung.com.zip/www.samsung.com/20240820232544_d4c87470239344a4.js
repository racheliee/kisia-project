function Bd(e) {
zb.push(e),Kb!==Wb&&jd()
}