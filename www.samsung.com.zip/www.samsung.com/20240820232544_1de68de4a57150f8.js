function te(e) {
var t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:2;if(e&&j(e))return+e.toFixed(t)
}