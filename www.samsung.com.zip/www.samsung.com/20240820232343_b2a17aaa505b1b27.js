function user() {

    $(".user__list").on("mouseleave", function () {
      $(this).parent().removeClass("active");
      mask("close");
    });
  
}