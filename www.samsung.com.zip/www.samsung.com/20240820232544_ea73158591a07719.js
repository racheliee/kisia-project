function t(e,t,n) {
e.addEventListener(t,n)
}