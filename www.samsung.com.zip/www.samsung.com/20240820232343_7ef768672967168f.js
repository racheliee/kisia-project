function chat_open() {

			fcTrack('click','floating chat:chat bot');
			var popupX = (window.screen.width / 2) - (356 / 2);
		    var popupY = (window.screen.height / 2) - (750 / 2);
		
		    /* 만 나이별로 agepass 구분값 전송
		     * 14세 이상 => 'y'
		     * 14세 미만 => 'n'
		     * 로그인하지 않을경우 => 'u'
		     */
		    var agepass = null;  
		    var birthAge = null;
			var birthDate = $.cookie("birthDate_1_");
			
			if(birthDate != 0 && birthDate != null){
				birthAge = checkAge(birthDate); 
			}
		    if( birthAge == "" || birthAge == null || birthAge == undefined ) {
		    	agepass = "u";
		    } else if(birthAge > 13) {
		    	agepass = "y";
		    } else if(birthAge < 14) {
		    	agepass = "n";
		    }
		    window.open('/sec/chatbot/?agepass='+ agepass, 'chatbot', 'status=no, height=750, width=356, left=' + popupX + ', top=' + popupY + ', screenX=' + popupX + ', screenY= ' + popupY);
		
}