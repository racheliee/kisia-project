function dl(e) {
var t=e.style,n=void 0===t?{}:t,a={};return a.selector=e.selector,a.cssSelector=e.cssSelector,p(n.left)||p(n.top)?p(n.width)||p(n.height)?(a.type=up,a.content=n,a):(a.type=fp,a.content=n,a):(a.type=hp,a.content=n,a)
}