function si(e) {
var t=e.response;return ri(t)&&$t(t.id.tntId),$t(null),e
}