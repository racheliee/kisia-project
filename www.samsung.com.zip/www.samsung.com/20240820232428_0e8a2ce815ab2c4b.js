function sn(e) {
Ve(e,(function(e){e()})),e.length=0
}