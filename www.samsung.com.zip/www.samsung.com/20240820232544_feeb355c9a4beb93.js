function Sl(e,t) {
var n=t.metrics;if(!D(n)){var a=t.name;w((function(t){t.name=a,t.selector=t.selector||e}),n)}
}