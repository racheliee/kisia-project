function closeEventUnpack2() {

        $('#ifmVideo2').attr("src", "");
        $('#ifmVideo2').attr("data-popup-target", "");
        $('.carousel-container .slide-play').click();
    
}