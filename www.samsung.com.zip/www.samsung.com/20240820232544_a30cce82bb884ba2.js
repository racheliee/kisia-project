function Ss(e,t) {
var n=e[rh],a=t.mbox,r={},i={},s={};a===n?i.pageLoad={}:i.mboxes=[{index:0,name:a}],r.execute=i;var o=Gr(a,r);D(o)||(s.analytics=o);var c=ws(e);return D(c)||(s.platform=c),D(s)||(r.experienceCloud=s),r
}