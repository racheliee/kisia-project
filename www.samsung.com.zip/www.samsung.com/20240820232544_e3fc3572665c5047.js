function Sd(e,t) {
var n=t[jf],a=ru.default({},t),r=v(t.params)?t.params:{};return a[Bf]=ru.default({},Aa(n),r),a[ah]=vr(e,t[ah]),a[Df]=m(t[Df])?t[Df]:Mu,a[Ef]=m(t[Ef])?t[Ef]:Mu,a
}