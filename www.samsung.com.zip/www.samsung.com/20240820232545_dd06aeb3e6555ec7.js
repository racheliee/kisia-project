function cardImgSwiper() {
new Swiper(".cardImgSwiper",{slidesPerView:1,on:{activeIndexChange:function activeIndexChange(e){var swiper=this;var val=swiper.el.querySelectorAll(".swiper-slide-active");var omni;val.forEach(function(e){omni=e.dataset.omni});pfSwiperTrack("activeIndexChange",omni);$(".swiper-slide").attr("aria-hidden","true");setTimeout(function(){$(".swiper-slide-active").attr("aria-hidden","false")},0)},init:function(swiper){$(".swiper-slide").attr("aria-hidden","true");$(".swiper-slide-active").attr("aria-hidden",
"false")}}})
}