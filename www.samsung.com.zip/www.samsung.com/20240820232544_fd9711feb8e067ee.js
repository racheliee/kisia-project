function i(t) {
var n=e(t),a=localStorage.getItem(n);return localStorage.removeItem(n),a
}