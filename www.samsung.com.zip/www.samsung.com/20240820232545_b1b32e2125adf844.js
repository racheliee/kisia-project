function callApplicationMenu(menuName) {

        if(device.isIosApp) {
            if(menuName === "samsungApp") {
                return;
            }

            if (
                window.location.hostname == 'dev-www.samsung.com'
                || window.location.hostname == 'stg-www.samsung.com'
                || window.location.hostname == 'www.samsung.com'
                || window.location.hostname == 'dev-familynet.samsung.com'
                || window.location.hostname == 'stg-familynet.samsung.com'
                || window.location.hostname == 'familynet.samsung.com'
            ) {
                window.webkit.messageHandlers.callNative.postMessage(JSON.stringify({fun:"callAppMenu", p1:menuName}));
            } else {
                console.log('메시지를 보낼 수 없는 도메인입니다.');
            }

        } else if(window.secapp) {
            window.secapp.callAppMenu(menuName);
        }
    
}