function appToastIClose(flag) {

    $("#mask").fadeIn("fast").remove();
    $(".toast-parent").removeClass("active");
    var atpc = $("#chk-not-see-appP").is(":checked");
    setCookieA("appSetYN","N",atpc ? 7 : 1);
    setTimeout(function(){$(".toast-parent").remove()},2000);
    if(flag){
        appWebAutoLogin2();// 웹앱연계 자동로그인.
    }

}