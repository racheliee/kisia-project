function m(e,t) {
return Object.prototype.hasOwnProperty.call(e,t)
}