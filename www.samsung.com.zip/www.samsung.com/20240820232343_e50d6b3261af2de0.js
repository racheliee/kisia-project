function closeEventUnpack3() {

        $('#ifmVideo3').attr("src", "");
        $('#ifmVideo3').attr("data-popup-target", "");
        $('.carousel-container .slide-play').click();
    
}