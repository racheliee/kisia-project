function bind(b,el,opts) {
var full=el==window,$el=$(el);if(!b&&(full&&!pageBlock||!full&&!$el.data("blockUI.isBlocked")))return;$el.data("blockUI.isBlocked",b);if(!full||!opts.bindEvents||b&&!opts.showOverlay)return;var events="mousedown mouseup keydown keypress keyup touchstart touchend touchmove";if(b)$(document).bind(events,opts,handler);else $(document).unbind(events,handler)
}