function Pn(e) {
var t={client_id:en()};return e.approvalType&&(t.approval_type=e.approvalType),e.scope&&(t.scope=e.scope),e.state&&(t.state=e.state),t
}