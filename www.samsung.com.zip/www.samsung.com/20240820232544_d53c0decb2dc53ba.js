function bi(e,t) {
return e.onerror=function(){t(new Error(Mg))},e
}