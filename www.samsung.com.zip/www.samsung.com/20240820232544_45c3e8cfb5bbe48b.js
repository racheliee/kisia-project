function eo(e) {
return _(wu,B(Xs,A(en(Rp,e))))
}