function h(e,t) {
var n=!1;try{e((function(e){n||(n=!0,d(t,e))}),(function(e){n||(n=!0,u(t,e))}))}catch(e){if(n)return;n=!0,u(t,e)}
}