function y() {
var e=setTimeout;return function(){return e(_,1)}
}