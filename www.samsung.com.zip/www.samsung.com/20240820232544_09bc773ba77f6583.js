function Oo(e) {
var t=so(e);switch(t[Qu]){case ip:return lo(t);case op:return uo(t);case yp:return fo(t);case wp:return vo(t);case xp:return go(t);case _p:return ko(t);case Vp:return Vo(t);case mp:return Co(t);case lp:return To(t);case dp:return wo(t);case up:return Po(t);case fp:return $o(t);case hp:return So(t);case vp:return Eo(t);case pp:return Io(t);default:return ot(t)}
}