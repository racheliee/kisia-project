function K(e,t) {
return{execute:function(n){return e.evaluate(n)?t:[]},toString:function(){return"Rule{condition=".concat(e,", consequences=").concat(t,"}")}}
}