function tt(e) {
return"number"==typeof e||d(e)&&"[object Number]"==p(e)
}