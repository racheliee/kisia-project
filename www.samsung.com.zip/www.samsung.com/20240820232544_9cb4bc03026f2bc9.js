function Xt(e,t) {
return zt(t).is(e)
}