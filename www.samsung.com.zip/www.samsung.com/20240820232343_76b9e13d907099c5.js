function viewLiveVideo() {

        //var srcUrl = "https://players.brightcove.net/901973578001/SyyzJXxCw_default/index.html?playlistId=1739041608073945194";
        //var srcUrl = "https://www.youtube.com/embed/YLNI23HS2mM?rel=0";
        //https://www.youtube.com/embed/YLNI23HS2mM?wmode=opaque&rel=0&enablejsapi=1&version=3&origin=https://p6-qa.samsung.com&autoplay=1&mute=1
        var srcUrl = "https://www.youtube.com/embed/qhtNyJt22rY?rel=0";
        if (isIe()) {
            srcUrl = "https://www.youtube.com/embed/qhtNyJt22rY?rel=0";
        }

        $('#ifmVideo').attr("src", srcUrl);
        pauseKV();
    
}