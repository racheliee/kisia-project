function g(n,i) {
document.cookie=n+"="+i+"; path=/;Domain=samsung.com;SameSite=Strict;max-age=31536000"
}