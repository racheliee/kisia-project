function Lt(e,t) {
var n=Ot(em,e);n.redirect=t,It(Ev,Sv,em,n)
}