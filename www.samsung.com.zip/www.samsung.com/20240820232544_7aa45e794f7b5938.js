function me(e) {
if(ve(e))return e;var t=H(G(".",e)),n=t.length;return n>=3&&Av.test(t[1])?t[2]+"."+t[1]+"."+t[0]:1===n?t[0]:t[1]+"."+t[0]
}