function tr(e) {
return e[ag]
}