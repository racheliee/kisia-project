function Sc(e,t,n) {
return B((function(e){return ru.default({key:t,page:n},e)}),_($c,e))
}