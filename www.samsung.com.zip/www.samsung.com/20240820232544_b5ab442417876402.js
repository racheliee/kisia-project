function ol(e) {
var t={};return t.type=Vp,t.content=e.content,t.selector=e.selector,t.cssSelector=e.cssSelector,t
}