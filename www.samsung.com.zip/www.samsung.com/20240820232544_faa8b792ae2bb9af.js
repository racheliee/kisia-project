function A(e) {
return p(e)?[]:S(e)?x(e)?O(e):I(e):E(k(e),e)
}