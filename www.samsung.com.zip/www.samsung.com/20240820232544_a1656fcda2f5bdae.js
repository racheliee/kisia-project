function ll(e) {
var t={};if(t.selector=e.selector,t.cssSelector=e.cssSelector,e.attribute===Mp)return t.type=dp,t.content=e.value,t;t.type=lp;var n={};return n[e.attribute]=e.value,t.content=n,t
}