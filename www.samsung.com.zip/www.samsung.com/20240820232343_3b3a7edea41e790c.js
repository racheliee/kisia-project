function s(n,i,u) {
return n=S(n,i,u),n.push(2),n
}