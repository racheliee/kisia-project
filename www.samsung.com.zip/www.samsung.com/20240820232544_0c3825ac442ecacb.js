function Bs(e,t,n) {
return st((function(a,r){var i=nt((function(){var t=n(e);D(t)||(i.disconnect(),a(t))}));z((function(){i.disconnect(),r(Fs(e))}),t),i.observe(Sv,{childList:!0,subtree:!0})}))
}