function t() {
r||(r=!0,window.CS_CONF&&(CS_CONF.integrations=CS_CONF.integrations||[],CS_CONF.integrations.push("Adobe Analytics - v"+a)))
}