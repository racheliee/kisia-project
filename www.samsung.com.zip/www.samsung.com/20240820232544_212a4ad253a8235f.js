function T(e) {
return"object"===V(e)||void 0===e
}