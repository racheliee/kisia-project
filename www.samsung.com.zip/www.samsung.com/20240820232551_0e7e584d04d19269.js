function b() {
picturePolyfill.parse(document)
}