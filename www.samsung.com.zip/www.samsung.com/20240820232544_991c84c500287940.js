function Mo(e) {
var t=e.key;if(N(t))return!0;if(e[Qu]===mp)return e[Uh];var n=e[ap],a=Ls(rb,n);return a!==t||a===t&&!e[Uh]
}