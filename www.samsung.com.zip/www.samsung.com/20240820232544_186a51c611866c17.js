function zd() {
We(ek,arguments)
}