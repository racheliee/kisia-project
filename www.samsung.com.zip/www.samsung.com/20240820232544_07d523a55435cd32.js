function ii(e) {
var t=e.response;return ri(t)&&wt(t.id.tntId),e
}