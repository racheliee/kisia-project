function r(t) {
return function n(){var r=a();if(r){var i=M[r[0]];e[i](n,!0)}else t()}
}