function screenLock(action) {

      if(action == 'lock'){
        $("html, body").css({
          height: 100 + "%",
          overflow: "hidden",
        });
      }else{
        $("html, body").css({
          height: "auto",
          overflow: "unset",
        });
      }
    
}