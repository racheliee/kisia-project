function F(e) {
return e.replace(R,"ms-").replace(I,W)
}