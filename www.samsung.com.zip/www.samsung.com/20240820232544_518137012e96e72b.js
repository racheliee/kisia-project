function n(e) {
for(var t=e.toLowerCase().split(":"),n=[],a=0,r=0;r<t.length;r++)t[r]&&t[r].length>0&&(n[a]=t[r],a++);return n
}