function o(e) {
return V[e]||k&&_[e]||e
}