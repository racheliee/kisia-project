function NetFunnel_goFunc(c,b,a) {
if(typeof b!="function"){alert("[NetFUNNEL] Invalid input function");return false}if(typeof a!="function")a=function(e,d){return false};NetFunnel_init(null,c);NetFunnel_getTidChkEnter({success:b,error:b,bypass:b,stop:a});return false
}