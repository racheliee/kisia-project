function checkKeysInt(e) {
var thisNums=e.target.value;e.target.value=thisNums.replace(/[^0-9]/g,"")
}