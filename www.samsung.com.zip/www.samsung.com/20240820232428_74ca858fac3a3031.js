function Ze(e) {
return d(e)&&1===e.nodeType&&!function(e){if(!d(e)||"[object Object]"!=p(e))return!1;var t=Le(e);if(null===t)return!0;var n=qe.call(t,"constructor")&&t.constructor;return"function"==typeof n&&n instanceof n&&De.call(n)==Ne}(e)
}