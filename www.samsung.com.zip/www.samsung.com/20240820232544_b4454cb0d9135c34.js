function fr(e) {
var t=e.url,n=e.headers,a=e.body,r=e.timeout,i=e.async;return st((function(e,s){var o=new window.XMLHttpRequest;(o=dr(o=lr(o,e,s),s)).open(lg,t,i),o.withCredentials=!0,o=pr(o,n),i&&(o=ur(o,r,s)),o.send(JSON.stringify(a))})).then((function(e){var t=e.response,n=t.status,a=t.message;if(!p(n)&&!p(a))throw new Error(a);return t}))
}