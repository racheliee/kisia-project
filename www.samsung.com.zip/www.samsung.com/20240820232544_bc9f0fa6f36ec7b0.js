function s(e,t) {
return o(e)||c(e,t)||l(e,t)||u()
}