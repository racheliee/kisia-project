function s(e) {
const t=d.split(".");for(let n=0;n<t.length;n++){if(void 0===e[t[n]])return;e=e[t[n]]}return e
}