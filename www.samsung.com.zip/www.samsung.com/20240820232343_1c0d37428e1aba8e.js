function w() {
const n="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";let i="";const u=n.length;for(let o=0;o<32;o++)i+=n.charAt(Math.floor(Math.random()*u));return i
}