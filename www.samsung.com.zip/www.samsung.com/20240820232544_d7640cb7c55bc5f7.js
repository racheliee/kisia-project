function r(e) {
v.addEntry(a(e))
}