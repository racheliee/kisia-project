function v() {
var e=0,t=new p(_),n=document.createTextNode("");return t.observe(n,{characterData:!0}),function(){n.data=e=++e%2}
}