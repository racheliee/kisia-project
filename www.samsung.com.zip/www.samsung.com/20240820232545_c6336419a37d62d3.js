function setLogoutGnbMenu() {
 
        // 모바일
        //if(device.agent.indexOf("mobi") >= 0 || device.isGnb === false){
            var htmlMoLoginBefore = '';
            
            // 로그인
            htmlMoLoginBefore += '<li>';
            htmlMoLoginBefore +=	'<a href="javascript:doLogin();" data-omni=\'login\'>';
            //htmlMoLoginBefore +=		'<img loading="lazy" src="/sec/static/_images/gnb/icon-mypage-01.svg" alt="로그인 아이콘">로그인';
            htmlMoLoginBefore +=		'<svg id="icon-svg-my-01" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="currentColor">';
            htmlMoLoginBefore +=			'<rect width="18" height="18" fill="none"/>';
            htmlMoLoginBefore +=			'<path d="M23.219,12.5a5.746,5.746,0,0,1,5.719,5.542h0v1.49a.657.657,0,0,1-.656.656H18.156a.657.657,0,0,1-.656-.656h0v-1.49A5.746,5.746,0,0,1,23.219,12.5Zm0,.938a4.81,4.81,0,0,0-4.781,4.6h0V19.25H28V18.042a4.809,4.809,0,0,0-4.7-4.6h-.077Zm0-9.937a3.844,3.844,0,1,1-3.844,3.844A3.844,3.844,0,0,1,23.219,3.5Zm0,.938a2.906,2.906,0,1,0,2.906,2.906A2.906,2.906,0,0,0,23.219,4.438Z" transform="translate(-14.125 -2.75)"/>';
            htmlMoLoginBefore +=		'</svg>';
            htmlMoLoginBefore +=		'로그인';
            htmlMoLoginBefore +=	'</a>';
            htmlMoLoginBefore += '</li>';
            
            // 회원가입
            htmlMoLoginBefore += '<li>';
            htmlMoLoginBefore +=	'<a href="javascript:doSignUp()" data-omni=\"sign up\">';
            //htmlMoLoginBefore +=		'<img loading="lazy" src="/sec/static/_images/gnb/icon-mypage-02.svg" alt="회원가입 아이콘">회원가입';
            htmlMoLoginBefore +=		'<svg id="icon-svg-my-02" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18">';
            htmlMoLoginBefore +=			'<rect width="18" height="18" fill="none"/>';
            htmlMoLoginBefore +=			'<path d="M56.787,62.513A3.2,3.2,0,0,1,53.6,59.306a3.115,3.115,0,0,1,.938-2.269,3.191,3.191,0,0,1,2.269-.937h0a3.2,3.2,0,0,1,3.206,3.188,3.237,3.237,0,0,1-3.225,3.225Zm0-5.606a2.4,2.4,0,0,0,.019,4.8h0a2.4,2.4,0,0,0,2.4-2.4,2.31,2.31,0,0,0-.712-1.687,2.383,2.383,0,0,0-1.706-.712Z" transform="translate(-43.287 -45.581)"/>';
            htmlMoLoginBefore +=			'<path d="M29.438,18.55m-4.612,2.138H18.656A.664.664,0,0,1,18,20.031h0V18.55a5.7,5.7,0,0,1,7.913-5.1l-.825.694a4.247,4.247,0,0,0-1.294-.206h-.075a4.808,4.808,0,0,0-4.781,4.612h0v1.2h5.888ZM23.719,4a3.844,3.844,0,1,1-3.844,3.844A3.849,3.849,0,0,1,23.719,4Zm0,.938a2.906,2.906,0,1,0,2.906,2.906A2.9,2.9,0,0,0,23.719,4.938Zm1.106,15.75" transform="translate(-14.362 -3.25)"/>';
            htmlMoLoginBefore +=			'<rect width="0.638" height="3.675" transform="translate(13.181 11.888)"/>';
            htmlMoLoginBefore +=			'<rect width="3.675" height="0.638" transform="translate(11.663 13.406)"/>';
            htmlMoLoginBefore +=		'</svg>';
            htmlMoLoginBefore +=		'회원가입';
            htmlMoLoginBefore +=	'</a>';
            htmlMoLoginBefore += '</li>';
            
            // 삼성계정을 만들어야 하는 이유
            htmlMoLoginBefore += '<li class="variety">';
            htmlMoLoginBefore +=     '<a href="/sec/why-samsung-account/" data-omni=\"why_samsung_account\">';
          //htmlMoLoginBefore +=         '<svg id="icon-svg-my-03" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18">';
          //htmlMoLoginBefore +=             '<rect width="18" height="18" fill="none"></rect>';
          //htmlMoLoginBefore +=         '</svg>';
            htmlMoLoginBefore +=         '삼성계정을 만들어야 하는 이유';
            htmlMoLoginBefore +=         '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" style="margin-left: auto;">';
            htmlMoLoginBefore +=             '<g id="icon-16-midium-down" transform="translate(0 16) rotate(-90)">';
            htmlMoLoginBefore +=                 '<path id="Path_327" data-name="Path 327" d="M514.321,186.333l6.29,6.29,6.29-6.29" transform="translate(-512.821 -180.912)" fill="none" stroke="#000" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"></path>';
            htmlMoLoginBefore +=                 '<rect id="Rectangle_221" data-name="Rectangle 221" width="16" height="16" fill="none"></rect>';
            htmlMoLoginBefore +=             '</g>';
            htmlMoLoginBefore +=         '</svg>';
            htmlMoLoginBefore +=     '</a>';
            htmlMoLoginBefore += '</li>';
            
            // 주문/배송 조회
            htmlMoLoginBefore += '<li>';
            htmlMoLoginBefore +=	'<a href="/sec/mypage/order/indexDeliveryList/" data-omni=\'orders\'>';
            //htmlMoLoginBefore +=		'<img loading="lazy" src="/sec/static/_images/gnb/icon-mypage-03.svg" alt="주문/배송 조회 아이콘">주문/배송 조회';
            htmlMoLoginBefore +=		'<svg id="icon-svg-my-03" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18">';
            htmlMoLoginBefore +=			'<rect width="18" height="18" fill="none"/>';
            htmlMoLoginBefore +=			'<path d="M17.78,23.837a.313.313,0,0,1-.249.1H16.16a2.1,2.1,0,0,0-3.222-1.062V17h3.078a.713.713,0,0,1,.654.541l.058.3H14.9a.561.561,0,0,0-.558.563v2.063a.561.561,0,0,0,.558.563h2.44l.489,2.543A.313.313,0,0,1,17.78,23.837Zm-2.391,1.038a1.266,1.266,0,0,1-2.5-.282,1.266,1.266,0,0,1,2.531,0A1.268,1.268,0,0,1,15.389,24.875ZM17.2,20.281h-2.1V18.594h1.779ZM12,23.938H7.535a2.108,2.108,0,0,0-4.007,0H2.438v-9H12v9Zm-5.236.938a1.244,1.244,0,1,1,.033-.281A1.267,1.267,0,0,1,6.764,24.875ZM18.752,23.4l-1.161-6.034a1.648,1.648,0,0,0-1.575-1.3H12.938V14.656A.657.657,0,0,0,12.281,14H2.156a.657.657,0,0,0-.656.656v9.562a.657.657,0,0,0,.656.656H3.443a2.107,2.107,0,0,0,4.177,0h4.448a2.107,2.107,0,0,0,4.177,0h1.287A1.215,1.215,0,0,0,18.752,23.4Z" transform="translate(-1.125 -11.375)"/>';
            htmlMoLoginBefore +=		'</svg>';
            htmlMoLoginBefore +=		'주문/배송 조회';
            htmlMoLoginBefore +=	'</a>';
            htmlMoLoginBefore += '</li>';
            
            // 멤버십
            htmlMoLoginBefore += '<li>';
            htmlMoLoginBefore +=	'<a href="/sec/membership/membershipMain/" data-omni=\'membership\'>';
            //htmlMoLoginBefore +=		'<img loading="lazy" src="/sec/static/_images/gnb/icon-mypage-05.svg" alt="멤버십 아이콘">멤버십';
            htmlMoLoginBefore +=		'<svg id="icon-svg-my-05" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18">';
            htmlMoLoginBefore +=			'<rect width="18" height="18" fill="none"/>';
            htmlMoLoginBefore +=			'<g transform="translate(1 2.5)" fill="none" stroke="#000" stroke-width="1">';
            htmlMoLoginBefore +=				'<rect width="16" height="13" rx="3" stroke="none"/>';
            htmlMoLoginBefore +=				'<rect x="0.5" y="0.5" width="15" height="12" rx="2.5" fill="none"/>';
            htmlMoLoginBefore +=			'</g>';
            htmlMoLoginBefore +=			'<line x2="15" transform="translate(1.5 12)" fill="none" stroke="#000" stroke-width="1"/>';
            htmlMoLoginBefore +=			'<g transform="translate(3.6 5.1)" fill="none" stroke="#000" stroke-width="1">';
            htmlMoLoginBefore +=				'<rect width="3" height="3" rx="1" stroke="none"/>';
            htmlMoLoginBefore +=				'<rect x="0.5" y="0.5" width="2" height="2" rx="0.5" fill="none"/>';
            htmlMoLoginBefore +=			'</g>';
            htmlMoLoginBefore +=		'</svg>';
            htmlMoLoginBefore +=		'멤버십';
            htmlMoLoginBefore +=	'</a>';
            htmlMoLoginBefore += '</li>';
            
            // 나의 제품 관리
            htmlMoLoginBefore += '<li>';
            htmlMoLoginBefore +=	'<a href="javascript:void(0);"  onclick="NetFunnel_Action({action_id:\'b2c_gnb_login\'},\'/sec/mypage/info/indexMyDeviceList/\');return false;" data-omni=\'my device\'>';
            //htmlMoLoginBefore +=		'<img loading="lazy" src="/sec/static/_images/gnb/icon-mypage-08.svg" alt="나의 제품 관리 아이콘">나의 제품 관리';
            htmlMoLoginBefore +=		'<svg id="icon-svg-my-08" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="18" height="18" viewBox="0 0 18 18">';
            htmlMoLoginBefore +=			'<defs>';
            htmlMoLoginBefore +=				'<clipPath id="clip-path">';
            htmlMoLoginBefore +=					'<rect width="15.004" height="14.533" fill="none"/>';
            htmlMoLoginBefore +=				'</clipPath>';
            htmlMoLoginBefore +=			'</defs>';
            htmlMoLoginBefore +=			'<g transform="translate(-4353 -1170)">';
            htmlMoLoginBefore +=				'<g transform="translate(4355 1172)">';
            htmlMoLoginBefore +=					'<g transform="translate(0 0)" clip-path="url(#clip-path)">';
            htmlMoLoginBefore +=						'<path d="M7.278,10.387l-.189.139L7.106,13.6l-4.377.017v-3.1l-.189-.139a3.854,3.854,0,0,1,0-6.248L2.729,4,2.712.928,7.089.911V2.362c.083-.093.167-.187.258-.274a4.864,4.864,0,0,1,.685-.559V.911A.919.919,0,0,0,7.106,0H2.712a.92.92,0,0,0-.926.911V3.542a4.77,4.77,0,0,0,0,7.442v2.638a.92.92,0,0,0,.926.911H7.106a.919.919,0,0,0,.926-.911V10.984a4.874,4.874,0,0,0,.937-1.018,4.9,4.9,0,0,1-.842-.434,3.982,3.982,0,0,1-.849.855" transform="translate(0 0)" fill="#1a1311"/>';
            htmlMoLoginBefore +=						'<path d="M26.238,5.027A4.023,4.023,0,0,0,23.4,6.18a3.8,3.8,0,0,0-1.172,2.791,3.97,3.97,0,0,0,3.985,3.945,4.015,4.015,0,0,0,4.032-3.968,3.971,3.971,0,0,0-4.009-3.922m0,6.9a2.953,2.953,0,1,1-.024-5.906h0a3,3,0,0,1,2.133.876,2.82,2.82,0,0,1,.891,2.076,2.983,2.983,0,0,1-3,2.953" transform="translate(-15.243 -3.472)" fill="#1a1311"/>';
            htmlMoLoginBefore +=						'<path d="M31.792,12.418h-1.1V11.371a.563.563,0,0,0-1.125,0v1.047h-1.1a.554.554,0,1,0,0,1.107h1.1v1.047a.563.563,0,0,0,1.125,0V13.525h1.1a.554.554,0,1,0,0-1.107" transform="translate(-19.133 -7.472)" fill="#1a1311"/>';
            htmlMoLoginBefore +=						'<path d="M4.977,16.6a3.9,3.9,0,1,1,0-7.8,4,4,0,0,1,1.384.25,4.643,4.643,0,0,1,.457-.822,4.947,4.947,0,0,0-1.841-.356,4.831,4.831,0,1,0,0,9.66A4.93,4.93,0,0,0,9.041,15.4a4.9,4.9,0,0,1-.845-.435A3.979,3.979,0,0,1,4.977,16.6" transform="translate(-0.047 -5.434)" fill="#1a1311"/>';
            htmlMoLoginBefore +=					'</g>';
            htmlMoLoginBefore +=				'</g>';
            htmlMoLoginBefore +=				'<rect width="18" height="18" transform="translate(4353 1170)" fill="none"/>';
            htmlMoLoginBefore +=			'</g>';
            htmlMoLoginBefore +=		'</svg>';
            htmlMoLoginBefore +=		'나의 제품 관리';
            htmlMoLoginBefore +=	'</a>';
            htmlMoLoginBefore += '</li>';
            
            // 쿠폰존
            htmlMoLoginBefore += '<li>';
            htmlMoLoginBefore +=	'<a href="javascript:void(0);" onclick="openCtaLink(\'/sec/mypage/coupon/indexCouponDownload/\',\'_self\');return false;" data-omni=\'coupon zone\'>';
            //htmlMoLoginBefore +=		'<img loading="lazy" src="/sec/static/_images/gnb/icon-mypage-04.svg" alt="쿠폰존 아이콘">쿠폰존';
            htmlMoLoginBefore +=		'<svg id="icon-svg-my-04" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18">';
            htmlMoLoginBefore +=			'<rect width="18" height="18" fill="none"/>';
            htmlMoLoginBefore +=			'<path d="M19.094,14.5a.469.469,0,0,1,.468.438v3.153a.469.469,0,0,1-.469.469,2.195,2.195,0,0,0-2.112,1.5A2.231,2.231,0,0,0,19.04,23h.084a.468.468,0,0,1,.437.437v3.153a.469.469,0,0,1-.438.468H2.969a.469.469,0,0,1-.468-.438V14.969a.469.469,0,0,1,.438-.468H19.094Zm-.469.937H8.125v1.219H7.187V15.438H3.437V26.125h3.75V25.094h.938v1.031h10.5V23.907l-.032,0a3.169,3.169,0,0,1-2.542-4l.017-.06.019-.063A3.106,3.106,0,0,1,18.5,17.678l.065-.012.063-.01V15.438Zm-10.5,6.281v1.688H7.188V21.719Zm0-3.375v1.688H7.188V18.344Z" transform="translate(-1.938 -11.688)"/>';
            htmlMoLoginBefore +=		'</svg>';
            htmlMoLoginBefore +=		'쿠폰존';
            htmlMoLoginBefore +=	'</a>';
            htmlMoLoginBefore += '</li>';
            
            // 삼성닷컴 회원 혜택
            htmlMoLoginBefore += '<li>';
            htmlMoLoginBefore +=	'<a href="/sec/eventList/benefitzone/" data-omni=\'event\'>';
            //htmlMoLoginBefore +=		'<img loading="lazy" src="/sec/static/_images/gnb/icon-mypage-06.svg" alt="삼성닷컴 회원 혜택 아이콘">삼성닷컴 회원 혜택';
            htmlMoLoginBefore +=		'<svg id="icon-svg-my-06" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18">';
            htmlMoLoginBefore +=			'<rect width="18" height="18" fill="none"/>';
            htmlMoLoginBefore +=			'<path d="M17.912,5a1.905,1.905,0,0,1,1.759,2.625h1.735a.657.657,0,0,1,.655.62v3.786a.657.657,0,0,1-.62.655h-.88v7.781a.657.657,0,0,1-.62.655H8.656A.657.657,0,0,1,8,20.5V12.688H7.156a.657.657,0,0,1-.655-.62V8.281a.657.657,0,0,1,.62-.655H8.892a1.9,1.9,0,0,1,2.673-2.392l.036.02.056.028.06.031c.139.073.334.185.585.34l.059.037c.549.343,1.189.79,1.92,1.354l-.07.054.238-.183c.626-.477,1.184-.865,1.671-1.174L16.2,5.69c.319-.2.554-.332.7-.408l.057-.029L17,5.234A1.894,1.894,0,0,1,17.843,5Zm-5.974,7.688h-3v7.5h3Zm3.75,0H12.875v7.5h2.813Zm3.938,0h-3v7.5h3ZM11.938,8.563h-4.5V11.75h4.5Zm3.75,0H12.875V11.75h2.813Zm5.438,0h-4.5V11.75h4.5ZM17.912,5.938a.957.957,0,0,0-.447.11l-.045.025-.02.012-.021.01c-.022.01-.074.037-.157.082-.128.07-.28.158-.456.267l-.067.042c-.47.294-1.015.671-1.634,1.14h3.488a.967.967,0,0,0-.641-1.688Zm-7.261,0a.967.967,0,0,0-.641,1.688H13.5c-.585-.443-1.1-.8-1.556-1.091l-.078-.049c-.181-.114-.339-.207-.473-.281l-.049-.027-.119-.063-.059-.028-.02-.012a.954.954,0,0,0-.492-.135Z" transform="translate(-5.188 -4.063)"/>';
            htmlMoLoginBefore +=		'</svg>';
            htmlMoLoginBefore +=		'삼성닷컴 회원 혜택';
            htmlMoLoginBefore +=	'</a>';
            htmlMoLoginBefore += '</li>';
            
            // 앱설정
            if(window.secapp || device.isIosApp) {
                htmlMoLoginBefore += '<li>';
                htmlMoLoginBefore +=	'<a href="javascript:void(0);" onclick="callApplicationMenu(\'settings\');">';
                //htmlMoLoginBefore +=		'<img loading="lazy" src="/sec/static/_images/gnb/icon-setting.svg" alt="설정 아이콘">설정';
                htmlMoLoginBefore +=		'<svg id="icon-svg-my-set" xmlns="http://www.w3.org/2000/svg" width="96" height="96" viewBox="0 0 96 96">';
                htmlMoLoginBefore +=			'<path d="M20.076-1.5A21.576,21.576,0,1,1-1.5,20.076,21.6,21.6,0,0,1,20.076-1.5Zm0,35.712A14.136,14.136,0,1,0,5.94,20.076,14.152,14.152,0,0,0,20.076,34.212Z" transform="translate(27.5 27.5)" fill="#010101"/>';
                htmlMoLoginBefore +=			'<path d="M64.911,9.7h16.12a6.085,6.085,0,0,1,5.841,4.554l.01.041,2.465,10.354a.373.373,0,0,0,.068.089l.183.092,2.182,1.455a1.755,1.755,0,0,0,.542.13L102.7,23.451a5.886,5.886,0,0,1,1.426-.176h0a6.144,6.144,0,0,1,5.051,2.713l.071.107,8.182,14.319.116.349A6.52,6.52,0,0,1,116.15,47.3l-7.688,7.688a.4.4,0,0,0-.15.346v.458l-.427,1.709a.891.891,0,0,0,.1.177l7.674,7.674a6.008,6.008,0,0,1,1.193,7.022l-.1.182-8,14-.071.107a6.144,6.144,0,0,1-5.051,2.713A5.887,5.887,0,0,1,102.2,89.2l-.12-.032-10.255-2.93a1.834,1.834,0,0,0-.631.167l-1.781,1.013a.37.37,0,0,0-.069.091l-2.729,10.42a6.086,6.086,0,0,1-5.834,4.526H64.663a6.086,6.086,0,0,1-5.834-4.526L56.1,87.507a.37.37,0,0,0-.069-.091l-.158-.085L54.25,86.4a1.834,1.834,0,0,0-.631-.167L43.245,89.2a5.887,5.887,0,0,1-1.427.176,6.144,6.144,0,0,1-5.051-2.713l-.071-.107L28.744,72.636a5.974,5.974,0,0,1,.8-7.286l7.688-7.688a.4.4,0,0,0,.15-.346v-2.2a1.13,1.13,0,0,0-.165-.391L29.284,46.79l-.2-.306a6.381,6.381,0,0,1-.48-6.455l.051-.1,8.3-14.336.065-.1a6.144,6.144,0,0,1,5.051-2.713,5.887,5.887,0,0,1,1.427.176l.12.032,10.255,2.93a1.834,1.834,0,0,0,.631-.167l1.781-1.013a.37.37,0,0,0,.069-.091l2.729-10.42A6.086,6.086,0,0,1,64.911,9.7Zm15,7.44H66L63.553,26.5a7.619,7.619,0,0,1-3.814,4.824l-1.845,1.047a9.245,9.245,0,0,1-4.046.986,7.2,7.2,0,0,1-1.744-.208l-.12-.032-9.263-2.647L35.669,42.653l6.824,6.824a8.329,8.329,0,0,1,2.33,5.606v2.232a7.777,7.777,0,0,1-2.33,5.606l-6.829,6.829L42.481,81.68,51.857,79A7.2,7.2,0,0,1,53.6,78.8a9.245,9.245,0,0,1,4.046.986l.182.1,1.663.95a7.619,7.619,0,0,1,3.814,4.824l2.451,9.36H79.689l2.451-9.36a7.619,7.619,0,0,1,3.814-4.824L87.8,79.781a9.245,9.245,0,0,1,4.046-.986A7.2,7.2,0,0,1,93.589,79l.12.032,9.256,2.645,6.726-11.771L102.7,62.923a8.329,8.329,0,0,1-2.33-5.606v-.458l.512-2.049a7.762,7.762,0,0,1,2.313-5.084l6.987-6.987-6.726-11.771-9.376,2.677a7.2,7.2,0,0,1-1.744.208,9.245,9.245,0,0,1-4.046-.986l-.207-.1-2.267-1.511a7.622,7.622,0,0,1-3.687-4.778l-.01-.041Z" transform="translate(-24.86 -7.7)" fill="#010101"/>';
                htmlMoLoginBefore +=			'<rect width="96" height="96" fill="none"/>';
                htmlMoLoginBefore +=		'</svg>';
                htmlMoLoginBefore +=		'설정';
                htmlMoLoginBefore +=	'</a>';
                htmlMoLoginBefore += '</li>';
            }

            $(".user__mypage__list ul").html(htmlMoLoginBefore);
            
        // PC
        //} else {
            var htmlLoginBefore = '';
            htmlLoginBefore += '<ul>';
            
            // 로그인
            htmlLoginBefore +=     '<li>';
            htmlLoginBefore +=         '<a href="javascript:doLogin();" data-omni=\'login\'>로그인</a>';
            htmlLoginBefore +=     '</li>';
            
            // 회원가입
            htmlLoginBefore +=     '<li>';
            htmlLoginBefore +=         '<a href="javascript:doSignUp();" data-omni=\"sign up\">회원가입</a>';
            htmlLoginBefore +=     '</li>';
            
            // 삼성계정을 만들어야 하는 이유
            htmlLoginBefore +=     '<li class="variety">';
            htmlLoginBefore +=         '<a href="/sec/why-samsung-account/" data-omni=\"why_samsung_account\">삼성계정을 만들어야 하는 이유';
            htmlLoginBefore +=             '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" style="margin-left: auto;">';
            htmlLoginBefore +=                 '<g id="icon-16-midium-down" transform="translate(0 16) rotate(-90)">';
            htmlLoginBefore +=                     '<path id="Path_327" data-name="Path 327" d="M514.321,186.333l6.29,6.29,6.29-6.29" transform="translate(-512.821 -180.912)" fill="none" stroke="#000" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"></path>';
            htmlLoginBefore +=                     '<rect id="Rectangle_221" data-name="Rectangle 221" width="16" height="16" fill="none"></rect>';
            htmlLoginBefore +=                 '</g>';
            htmlLoginBefore +=             '</svg>';
            htmlLoginBefore +=         '</a>';
            htmlLoginBefore +=     '</li>';
            
            // 주문/배송 조회
            htmlLoginBefore +=     '<li>';
            htmlLoginBefore +=         '<a href="/sec/mypage/order/indexDeliveryList/" data-omni=\'orders\'>주문/배송 조회</a>';
            htmlLoginBefore +=     '</li>';
            
            // 멤버십
            htmlLoginBefore +=     '<li>';
            htmlLoginBefore +=         '<a href="/sec/membership/membershipMain/" data-omni=\'membership\'>멤버십</a>';
            htmlLoginBefore +=     '</li>';
            
            // 나의 제품 관리
            htmlLoginBefore +=     '<li>';
            htmlLoginBefore +=         '<a href="javascript:void(0);"  onclick="NetFunnel_Action({action_id:\'b2c_gnb_login\'},\'/sec/mypage/info/indexMyDeviceList/\');return false;" data-omni=\'my device\'>나의 제품 관리</a>';
            htmlLoginBefore +=     '</li>';
            
            // 쿠폰존
            htmlLoginBefore +=     '<li>';
            htmlLoginBefore +=         '<a href="javascript:void(0);" onclick="openCtaLink(\'/sec/mypage/coupon/indexCouponDownload/\',\'_self\');return false;" data-omni=\'coupon zone\'>쿠폰존</a>';
            htmlLoginBefore +=     '</li>';
            
            // 삼성닷컴 회원 혜택
            htmlLoginBefore +=     '<li>';
            htmlLoginBefore +=         '<a href="/sec/eventList/benefitzone/" data-omni=\'event\'>삼성닷컴 회원 혜택</a>';
            htmlLoginBefore +=     '</li>';
            
            // 참여형 이벤트
            htmlLoginBefore +=     '<li>';
            htmlLoginBefore +=         '<a href="/sec/mypage/eventCollection/eventCollectionList/" data-omni=\'join event\'>참여형 이벤트</a>';
            htmlLoginBefore +=     '</li>';
            
            htmlLoginBefore += '</ul>';

            $(".user__list").html(htmlLoginBefore);
        //}
    
}