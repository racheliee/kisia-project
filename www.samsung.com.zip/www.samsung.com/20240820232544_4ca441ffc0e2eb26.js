function ln(e) {
return G(ym,e)
}