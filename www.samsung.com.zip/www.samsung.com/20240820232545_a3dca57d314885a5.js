function navLinkFixed() {
if(540>=
navLinkWin)if(navLinkSTop>navLinkOffset)navLinkEl.addClass("fixed");else navLinkEl.removeClass("fixed")
}