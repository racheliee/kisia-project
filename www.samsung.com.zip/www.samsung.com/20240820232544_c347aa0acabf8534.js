function md(e) {
var t={};return t.action=vp,t.selector=e.selector,t.cssSelector=e.cssSelector,t
}