function uo(e) {
var t=zt(e[ap]),n=e[Ku];return Qe(ff,e),et({action:e}),xn(n,t),ot(e)
}