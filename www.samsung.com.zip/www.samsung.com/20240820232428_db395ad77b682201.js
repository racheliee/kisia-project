function xt(e,t,n) {
return t&&St(e.prototype,t),n&&St(e,n),Object.defineProperty(e,"prototype",{writable:!1}),e
}