function Xi() {
var e=(arguments.length>0&&void 0!==arguments[0]?arguments[0]:{}).analytics;return D(e)?[]:[e]
}