function Zs(e) {
return Qe(wf,e),Ls(Mp,Ns(Mp,e,Kt("<"+Wp+"/>")))
}