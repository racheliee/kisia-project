function e(e) {
if(e)for(var t=e.split(":"),n=0;n<t.length;n++)if("#"==t[n].charAt(0)){t.splice(n,1),e=t.join(":");break}return e
}