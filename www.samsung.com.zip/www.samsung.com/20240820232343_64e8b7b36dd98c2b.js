function NetFunnel_sendStop(a) {
try{if(!NetFunnel.gControl)NetFunnel_init();NetFunnel.gAlreadyProc=0;NetFunnel.gControl.setNext(a);NetFunnel.gControl.sendStop();return true}catch(b){return false}
}