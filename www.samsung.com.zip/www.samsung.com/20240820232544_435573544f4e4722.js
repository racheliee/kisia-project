function a() {
var e=new Date,t=e.getFullYear(),n=e.getMonth()+1,a=e.getDate();1==n.length&&(n="0"+n),1==a.length&&(a="0"+a),today=t+""+n+a
}