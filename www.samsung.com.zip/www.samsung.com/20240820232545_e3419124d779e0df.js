function setLnbSwiper() {
if($("#lnb").hasClass("lnb-wrap")){var lnbSwiper_width=$(".lnbSwiper").outerWidth();var sum_li_width=0;$(".lnbSwiper .swiper-slide").each(function(){sum_li_width=$(this).outerWidth()+sum_li_width});if(lnbSwiper_width<sum_li_width)LnbSwiper()}
}