function Te(e,t,n) {
return{name:e,value:t,expires:n}
}