function dt(e) {
return lu(e)?ou.default.all(e):ct(new TypeError(Qv))
}