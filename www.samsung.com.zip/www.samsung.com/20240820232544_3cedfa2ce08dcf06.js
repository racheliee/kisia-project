function ce(e) {
var t=oe(e),n=t.version,a=t.rules;return{execute:function(e){return a.map((function(t){return t.execute(e)})).filter((function(e){return e.length>0}))},getVersion:function(){return n},numRules:function(){return a.length}}
}