function Bl(e) {
window.__target_telemetry.addServerStateEntry(e)
}