function bc(e,t,n,a) {
var r=n.type,i=n.selector,s=n.eventToken,o=P(r+":"+i+":"+s),c=function(){return a(e,r,s)};hc(r,i),t?vc(e,o)||(mc(e,r,i),gc(e,o,c),Go(r,c,i)):Go(r,c,i)
}