function Pe(e) {
return N(e)?[]:G("|",e)
}