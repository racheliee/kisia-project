function c() {
return s()
}