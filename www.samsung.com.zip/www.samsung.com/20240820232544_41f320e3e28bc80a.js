function Xs(e) {
var t=Ls(Mp,e);return wu(t)?t:null
}