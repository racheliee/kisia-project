function getCartCnt() {

        ajax.call({
            url : '/sec/xhr/order/gnbCartCount'
            , showWait : false
            , done: function (result) {
                if (result > 0) {
                    $('.cart__count').text(result);
                    $('.cart__count').show();
                } else {
                    $('.cart__count').hide();
                }
            }
        });
    
}