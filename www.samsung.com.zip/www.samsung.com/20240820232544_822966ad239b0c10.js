function Ln() {
In(ke())
}