function initPrint() {
fontInit();zoomInit()
}