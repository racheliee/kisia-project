function Re(e,t,n) {
return Le(n)||Ne(e,n)||je(t,n)
}