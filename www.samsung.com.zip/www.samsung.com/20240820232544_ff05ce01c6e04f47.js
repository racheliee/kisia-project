function e(t) {
return{noUnknownFields:function(){return xn(this,jn(t))},nonEmpty:ia,concat:function(n){var a=f(f({},t),n.schema);return xn(this,n,e(a))},deprecated:function(e,t,n){return Pn(this,An(e,t,n))},schema:t}
}