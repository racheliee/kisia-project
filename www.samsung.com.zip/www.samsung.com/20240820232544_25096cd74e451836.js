function go(e) {
return Qe(ff,e),ro(mo,e)
}