function B(t) {
return function(e){return fe(e,"input")&&e.type===t}
}