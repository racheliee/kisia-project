function fnSetPrdCouponPrice(goodsObjArr, siteGbCd, cptLytNo) {

	    	//if (!(siteGbCd === '10' || siteGbCd === '20' || siteGbCd === '70' || siteGbCd === '80')) return false;
	    	
	    	if (goodsObjArr != null && goodsObjArr.length > 0) {
    			var idStrArr = "";
    			var compNo = "";
    			var appendHtmlIndex = "";
    			var goodsId = "";
    			var couponPrice = 0;
    			var lastValue = "";
    			var priceLable = "쿠폰 적용 예상가";
    			
    			if(cptLytNo === 24 || cptLytNo === 46){
    				// Product Card, New Product Card 에 가격숨김 부분이 추가되면서 따로 처리함.
    				// 비로그인시 가격숨김 Show 이면 등록한 image 노출함.
    				// 가격숨김 Show를 했어도 url 또는 이미지 경로가 없으면 노출하지 않음.
    				var priceHiddenLoginUrl = ""; 	//가격숨김 로그인 URL
        			var priceHiddenImg = "";		//가격숨김 이미지
        			var priceHiddenImgATxt = "";	//가격숨김 Alt Text
        			var priceHiddenMoImg = "";		//가격숨김 모바일 이미지
        			var priceHiddenMoImgATxt = "";	//가격숨김 모바일 Alt Text
        			var priceHiddenHtml = '';
        			var chkStId = '1';
        			
        			//로그인 체크
        			var mbYn = "N";
        			$.ajax({
    	                url     : "/sec/xhr/member/getSession"
    	              , type    : "POST"
    	              , success : function(result) {
    	                    result = JSON.parse(result);
    	                    if (result.mbrNo != 0) {
    	                    	mbYn = "Y";
    	                    }
    					}
    				});
        			
        			var baseCompNo = $(goodsObjArr[0]).attr('id').split("_")[1];
    				var priceHiddenFlag = $("#slicePrdSel_" + baseCompNo).data("price-hidden-yn");
    				
    				if(priceHiddenFlag == "001"){
    					//가격숨김 Show = 001, hide = 002
       					priceHiddenLoginUrl = $("#slicePrdSel_" + baseCompNo).data("price-hidden-login-url");
               			priceHiddenImg = $("#slicePrdSel_" + baseCompNo).data("price-hidden-img");
               			priceHiddenImgATxt = $("#slicePrdSel_" + baseCompNo).data("price-hidden-img-alt-text");
               			
               			if(chkStId == "122") {
               				//갤캠스만 pc, mo 둘다 사용-등록할때 pc, mo 이미지 2개 등록
               				priceHiddenMoImg = $("#slicePrdSel_" + baseCompNo).data("price-hidden-mo-img");
                			priceHiddenMoImgATxt = $("#slicePrdSel_" + baseCompNo).data("price-hidden-mo-img-alt-text");
                			
           					if(priceHiddenLoginUrl != "" &&  priceHiddenImg != "" && priceHiddenMoImg != "") {
           						priceHiddenHtml += '<a class="pt_tag__price" href="' + priceHiddenLoginUrl + '">';
           						priceHiddenHtml += '	<img src="' + priceHiddenImg + '" class="m_hide" alt="' + priceHiddenImgATxt + '">';
           						priceHiddenHtml += '	<img src="' + priceHiddenMoImg + '" class="m_show" alt="' + priceHiddenMoImgATxt + '">'
           						priceHiddenHtml += '</a>';
           					}
						}else{
							if(priceHiddenLoginUrl != "" &&  priceHiddenImg != "") {
								priceHiddenHtml += '<a class="pt_tag__price" href="' + priceHiddenLoginUrl + '">';
								priceHiddenHtml += '	<img src="' + priceHiddenImg + '" class="m_hide" alt="' + priceHiddenImgATxt + '">';
								priceHiddenHtml += '</a>';
							}
						}
    				}
    				
    				for (var idx = 0; idx < goodsObjArr.length; idx++) {
       					idStrArr = $(goodsObjArr[idx]).attr('id').split("_");
       					couponPrice = $(goodsObjArr[idx]).data('coupon-price');
       					
       					if (idStrArr.length >= 4 && idStrArr[3] != '') {
       						compNo = idStrArr[1];
       						appendHtmlIndex = idStrArr[2];
        					goodsId = idStrArr[3];
        					
        					/*if(stGbCd === '20'){ // 특별판매가에 쿠폰적용예상가 넣기
								var idStrArr = $("[id^=gdPrc_"+compNo+"_][id$="+prd.goodsId+"]").attr('id').split('_');
								var appendHtmlIndex = idStrArr[2];
								var appendHtml = '';
								appendHtml += '<div class="pic-ben">';
								appendHtml += '	<span id="'+compNo+'_'+appendHtmlIndex+'_'+goodsId+'_lbl3">'+priceLable+'</span>';
								appendHtml += '	<em id="'+compNo+'_'+appendHtmlIndex+'_'+goodsId+'_prc3">'+fnComma(afterCoupon)+' 원</em>';
								appendHtml += '</div>';
	
								$("[id^=gdPrc_"+compNo+"_][id$="+goodsId+"]").find('.pic-ben:eq(0)').after(appendHtml);
								$("[id^=gdPrc_"+compNo+"_][id$="+goodsId+"]").find('div:last-child').find('em').text(lastValue+" 원");
							}else{*/
								if(mbYn == "N" && priceHiddenFlag == "001"){
									//비로그인 & 가격숨김 show
									if(priceHiddenHtml != ""){
										if(Number(couponPrice) > 0){
											$("[id^=gdPrc_"+compNo+"_][id$="+goodsId+"]").find('div:last-child').find('span').text(priceLable);
										}
	       								$("[id^=gdPrc_"+compNo+"_][id$="+goodsId+"]").find('div:last-child').find('em').html(priceHiddenHtml);
									}else{
										if(Number(couponPrice) > 0){
											$("[id^=gdPrc_"+compNo+"_][id$="+goodsId+"]").find('div:last-child').find('span').text(priceLable);
											$("[id^=gdPrc_"+compNo+"_][id$="+goodsId+"]").find('div:last-child').find('em').text(fnComma(couponPrice)+" 원");
										}
									}
								}else{
									if(Number(couponPrice) > 0){
										$("[id^=gdPrc_"+compNo+"_][id$="+goodsId+"]").find('div:last-child').find('span').text(priceLable);
										$("[id^=gdPrc_"+compNo+"_][id$="+goodsId+"]").find('div:last-child').find('em').text(fnComma(couponPrice)+" 원");
									}
								}
							//}
       					}
       				}
    			}else{
    				for (var idx = 0; idx < goodsObjArr.length; idx++) {
       					idStrArr = $(goodsObjArr[idx]).attr('id').split("_");
       					couponPrice = $(goodsObjArr[idx]).data('coupon-price');
       					
       					if (idStrArr.length >= 4 && idStrArr[3] != '' && Number(couponPrice) > 0) {
       						compNo = idStrArr[1];
       						appendHtmlIndex = idStrArr[2];
        					goodsId = idStrArr[3];
        					lastValue = fnComma(couponPrice);
        					
        					if(cptLytNo === 12 || cptLytNo === 45){ //Product Selection, New Product Selection
    							/*if(stGbCd === '20'){ // 특별판매가에 쿠폰적용예상가 넣기
    								var idStrArr = $("[id^=gdPrc_"+compNo+"_][id$="+prd.goodsId+"]").attr('id').split('_');
    								var appendHtmlIndex = idStrArr[2];
    								var appendHtml = '';
    								appendHtml += '<div class="pic-ben">';
    								appendHtml += '	<span id="'+compNo+'_'+appendHtmlIndex+'_'+goodsId+'_lbl3">'+priceLable+'</span>';
    								appendHtml += '	<em id="'+compNo+'_'+appendHtmlIndex+'_'+goodsId+'_prc3">'+fnComma(afterCoupon)+' 원</em>';
    								appendHtml += '</div>';

    								$("[id^=gdPrc_"+compNo+"_][id$="+goodsId+"]").find('.pic-ben:eq(0)').after(appendHtml);
    								$("[id^=gdPrc_"+compNo+"_][id$="+goodsId+"]").find('div:last-child').find('em').text(lastValue+" 원");
    							}else{*/
    								if($("[id^="+compNo+"_][id$=_"+goodsId+"_lbl3]").length > 0){
    									$("[id^="+compNo+"_][id$=_"+goodsId+"_lbl3]").text(priceLable);
    									$("[id^="+compNo+"_][id$=_"+goodsId+"_prc3]").text(lastValue + " 원");
    								}else{
    									var appendHtml = '';
    									appendHtml += '<div class="pic-ben">';
    									appendHtml += '	<span id="'+compNo+'_'+appendHtmlIndex+'_'+goodsId+'_lbl3">'+priceLable+'</span>';
    									appendHtml += '	<em id="'+compNo+'_'+appendHtmlIndex+'_'+goodsId+'_prc3">'+lastValue+' 원</em>';
    									appendHtml += '</div>';

    									$("[id^=gdPrc_"+compNo+"_][id$="+goodsId+"]").find('.pic-mem').after(appendHtml);
    								}
    							//}
    						}else if(cptLytNo === 21){ //Tab Container
    							if(stGbCd === '20'){
    								priceLable = '임직원가';
    							}
    							
    							$("[id^="+compNo+"_][id$="+goodsId+"_prclbl]").text(priceLable);
    							$("[id^=gdPrc_"+compNo+"_][id$="+goodsId+"_price]").text(lastValue + " 원");
    						}else if(cptLytNo === 39){ //Best Ranking
    							$("[id^=gdPrc_"+compNo+"_][id$="+goodsId+"]").find('dl:last-child').find('dt').text(priceLable);
    							$("[id^=gdPrc_"+compNo+"_][id$="+goodsId+"]").find('dl:last-child').find('dd').text(lastValue+"원");    
    							
    							/*if(svmnUseYn === 'Y'){ //적립예정포인트 노출여부 component bo값
    								if(stGbCd !== '80'){         
    									$("[id^="+compNo+"_][id$="+prd.goodsId+"_svmnt]").find('.point').text(fnComma(prd.membershipPoint) + "P");
    								}
    							}*/
    						}
       					}
       				}
    			}
    		}
	    
}