function De(e) {
var t=e.name,n=e.value,a=e.expires,r=e.domain,i=e.secure,s=$e();s[t]=Te(t,n,Math.ceil(a+q()/1e3)),Ae(s,r,i)
}