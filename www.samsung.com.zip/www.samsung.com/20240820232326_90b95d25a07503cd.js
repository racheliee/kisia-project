function v(aG,aF) {
if(localStorage){localStorage.setItem(aG,aF)}else{var aE=new Date();var aD=new Date();aD.setDate(aE.getDate()+200*365);var aC=aD.toUTCString();var aB=location.hostname.replace("www.","");ag(aG,aF,aB,aC)}
}