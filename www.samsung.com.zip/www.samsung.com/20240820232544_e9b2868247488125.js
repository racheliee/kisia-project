function _(e,t,n) {
null==n?e.removeAttribute(t):e.setAttribute(t,n)
}