function commonAlert(data) {
$("#commonAlert h2").text(data.title);$("#commonAlert p").html(data.content);$("#commonAlert a").text(data.btnText);if(data.focusId)$("#commonAlert a").data("focus-id",data.focusId);if(data.callback==="")data.callback=undefined;$("#commonAlert a").attr("onclick","closeLayer('commonAlert',"+data.callback+");");$("#commonAlert a").attr("data-focus-next","commonAlert")
}