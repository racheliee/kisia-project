function compareIconCtl(e) {
if($(this).hasClass("disabled"))this.classList.remove("disabled");else{this.classList.add("disabled");toastOpen(e)}
}