function oe(e) {
return null!=e&&re(e.length)&&!j(e)
}