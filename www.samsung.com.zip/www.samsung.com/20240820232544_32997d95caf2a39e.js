function Nc(e,t,n,a) {
var r=t.name;return dt(Oc((function(e){return Ec(e,r,n)}),t)).then((function(n){return Dc(e,t,n)})).then((function(e){return a(t),e}))
}