function a(r) {
if(r.target===this)for(e.call(this,r),t=0;t<i.length;t+=1)s.off(i[t],a)
}