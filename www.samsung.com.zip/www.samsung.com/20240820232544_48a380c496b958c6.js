function c(e) {
return e===Object(e)&&0===Object.keys(e).length
}