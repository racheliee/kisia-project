function st(e,t) {
return[e,t].reduce((function(e,t){return e.filter((function(e){return-1===t.indexOf(e)}))}))
}