function nn() {
Ev[fm]=Ev[fm]||{},Ev[fm].querySelectorAll=zt
}