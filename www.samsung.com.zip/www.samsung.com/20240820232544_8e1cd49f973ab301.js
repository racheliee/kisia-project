function r(e) {
var t={};return Object.keys(e).forEach((function(n){var r=e[n];if(a(r)){var i=r.checked,s=r.value;i&&""===s||(t[n]=s)}else t[n]=r})),t
}