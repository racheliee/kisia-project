function basicClose() {

      if (document.querySelector(".botnavi__mask")) {
        bnb.allClose();
      }
    
}