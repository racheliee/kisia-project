function ie(e) {
return Y(e.id,e.type,e.detail)
}