function bnbFirstRecentGoods() {

		$.ajax({
			url : "/sec/xhr/goods/getFirstRecentGoods",
			type : "POST",
			success : function(result) {
				var recentGoodsData = JSON.parse(result);
				var recentGoodsNm = recentGoodsData.recentGoodsNm;
				var html = "";
				if (recentGoodsData.recentYn === "Y") {
					html += '<a href="javascript:void(0);" id="btn-rcntgoods-floating" onclick="showLatestItem(self,\'latestItemLayer\'); getRecentGoods(); return false" data-omni="bnb_recently viewed products" data-st-path ="' + recentGoodsData.stContextPath + '">';
					html +=     '<div class="botnavi__recent">';
					html +=         '<img src="' + recentGoodsData.recentImgPath + '?$128_128_PNG$" alt="' + recentGoodsData.recentGoodsNm + '">';
					html +=     '</div>';
					html += '</a>';
					
					<!-- 모바일 퍼스트 검색창 추천 제품 세팅 추가 20240229 -->
					$("#recentGoodsNm").val(recentGoodsNm);
				}else{
					// 최근본 제품이 없는 경우에도 최근본 제품 팝업을 띄우도록 수정 - 2024.04.17 dslee
                    html += '<a href="javascript:void(0);" id="btn-rcntgoods-floating" onclick="showLatestItem(self,\'latestItemLayer\'); getRecentGoods(); return false" data-omni="bnb_recently viewed products" data-st-path ="' + recentGoodsData.stContextPath + '">';
                    html += '    <i class="icon default">                                                                                                                               ';
                    html += '        <svg id="bnb_ic_history" xmlns="http://www.w3.org/2000/svg" width="96" height="96" viewBox="0 0 96 96">                                            ';
                    html += '            <path id="Icon-_-Regular-_-Notification-_-Clock" data-name="Icon-/-Regular-/-Notification-/-Clock"                                             ';
                    html += '                d="M47.5,3A45.5,45.5,0,1,1,2,48.5,45.5,45.5,0,0,1,47.5,3Zm0,5A40.5,40.5,0,1,0,88,48.5,40.5,40.5,0,0,0,47.5,8ZM50,15.5V46H75.5v5H45V15.5Z"  ';
                    html += '                transform="translate(0.5 -0.5)">                                                                                                           ';
                    html += '            </path>                                                                                                                                        ';
                    html += '            <rect id="container" width="96" height="96" fill="none"></rect>                                                                                ';
                    html += '        </svg>                                                                                                                                             ';
                    html += '    </i>                                                                                                                                                   ';
                    html += '    <i class="icon active">                                                                                                                                ';
                    html += '        <svg id="bnb_ic_history_selected" xmlns="http://www.w3.org/2000/svg" width="96" height="96" viewBox="0 0 96 96">                                   ';
                    html += '            <path id="제외_2" data-name="제외 2"                                                                                                              ';
                    html += '                d="M45.5,91A45.5,45.5,0,1,1,91,45.5,45.553,45.553,0,0,1,45.5,91ZM43,12.5V48H73.5V43H48V12.5Z"                                              ';
                    html += '                transform="translate(2.999 2.999)">                                                                                                        ';
                    html += '            </path>                                                                                                                                        ';
                    html += '            <rect id="container" width="96" height="96" fill="none"></rect>                                                                                ';
                    html += '        </svg>                                                                                                                                             ';
                    html += '    </i>                                                                                                                                                   ';
                    html += '    <span>최근 본 제품</span>                                                                                                                                  ';
                    html += '</a>                                                                                                                                                       ';
				}
				$("#liRecentGoods").html(html);
			}
		});
	
}