function Qe() {
for(var e=arguments.length,t=new Array(e),n=0;n<e;n++)t[n]=arguments[n];ze(Ev,t)
}