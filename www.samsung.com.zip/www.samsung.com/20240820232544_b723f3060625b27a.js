function ye(e) {
try{return decodeURIComponent(e)}catch(t){return e}
}