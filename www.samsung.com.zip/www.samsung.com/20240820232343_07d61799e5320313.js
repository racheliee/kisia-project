function S(n,i,u) {
return n=n.concat(v(i)),n.push(3),n=n.concat(v(u)),n
}