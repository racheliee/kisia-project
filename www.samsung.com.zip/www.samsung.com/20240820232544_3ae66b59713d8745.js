function Xl(e) {
if(!v(e))return Ql(Yp);var t=Kl(e[jf]);if(!t[Af])return t;var n=e[Rf];return lu(n)?Wl():Ql(cf)
}