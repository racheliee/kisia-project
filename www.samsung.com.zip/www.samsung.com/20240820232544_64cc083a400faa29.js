function Ad(e) {
return Od(e),!e.preventDefault
}