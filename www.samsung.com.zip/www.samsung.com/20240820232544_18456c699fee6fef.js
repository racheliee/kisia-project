function Ze(e,t,n) {
var a=e[Oh]||[];if(e[Oh]=a,n){var r=a.push;a[sh]=Gv,a[Sh]=Ke(t),a[Eh]=[],a[Ih]=[],a.push=function(e){a[Ih].push(ru.default({timestamp:q()},e)),r.call(this,e)}}
}