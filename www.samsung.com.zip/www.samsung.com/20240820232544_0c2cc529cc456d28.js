function yc(e) {
return _c(e.name,!0,yb(e),uc)
}