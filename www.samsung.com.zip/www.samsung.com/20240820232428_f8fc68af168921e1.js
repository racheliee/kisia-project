function Ve(e,t) {
var n;return(f(e)?$:We)(e,"function"==typeof(n=t)?n:O)
}