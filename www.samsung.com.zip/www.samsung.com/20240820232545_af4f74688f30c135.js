function getWritableMyComment() {

        $.ajax({
              url : "/sec/xhr/review/loadWritableMyCommentListCount"
            , type : "POST"
            , dataType : "json"
            , contentType : "application/json; charset=utf-8"
            , success : function(result) {
                  $('.writableCnt').text(result.cmntCnt);
              }
            , error : function(request, status, error) {
              }
        });
    
}