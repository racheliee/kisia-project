function Pc(e) {
var t=_(yg,xg(e));return y(B(Tb,t))
}