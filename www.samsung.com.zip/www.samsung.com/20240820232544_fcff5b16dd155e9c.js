function T(e) {
return null!=e&&"object"===r(e)
}