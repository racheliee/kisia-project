function v(e) {
return"children"in e?D.call(e.children):P.map(e.childNodes,(function(e){if(1==e.nodeType)return e}))
}