function Ut(e) {
var t=e.charAt(0),n=e.charAt(1),a=e.charAt(2),r={key:e};return r.val="-"===n?""+t+n+"\\3"+a+" ":t+"\\3"+n+" ",r
}