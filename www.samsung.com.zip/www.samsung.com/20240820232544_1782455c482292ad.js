function Mc(e) {
Tc(Pc(e))
}