function u() {
let e=navigator.userAgentData;if(e!==void 0&&JSON.stringify(e.brands).includes("Google Chrome"))return"Chrome";let n=navigator.userAgent.toLowerCase();return n.indexOf("firefox")>-1?"Firefox":n.indexOf("samsungbrowser")>-1?"SamsungInternet":"NotSupported"
}