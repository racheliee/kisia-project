function s() {
var e=h.shift();if(e){var t=u.last(e);t.afterDequeue(),e.stream=o.apply(void 0,e),t.afterStreamStart()}
}