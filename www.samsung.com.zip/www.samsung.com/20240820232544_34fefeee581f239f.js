function F(e) {
return void 0===e
}