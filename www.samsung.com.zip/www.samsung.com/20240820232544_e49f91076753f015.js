function t(e,t) {
if(t)e:{var n=u;e=e.split(".");for(var a=0;a<e.length-1;a++){var r=e[a];if(!(r in n))break e;n=n[r]}(t=t(a=n[e=e[e.length-1]]))!=a&&null!=t&&d(n,e,{configurable:!0,writable:!0,value:t})}
}