function i() {
o.dispatchEvent(t+"Complete",null,[e])
}