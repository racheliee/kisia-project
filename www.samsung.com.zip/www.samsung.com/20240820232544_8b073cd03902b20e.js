function t() {
var e=a;return a=[],e
}