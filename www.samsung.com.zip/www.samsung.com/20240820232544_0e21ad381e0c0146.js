function Qa(e) {
return e===ig
}