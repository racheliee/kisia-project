function ctgrSlick(n) {
var _n=n;var _ctgr=$(".copmpo-rcmd-area .catagory ul");var ctgrSet={arrows:true,infinite:false,slidesToShow:_n,responsive:[{breakpoint:9999,settings:{arrows:true,slidesToShow:4}},{breakpoint:800,settings:{arrows:true,slidesToShow:3}}]};$(window).on("resize orientationchange",function(){_ctgr.slick("resize")});_ctgr.slick(ctgrSet)
}