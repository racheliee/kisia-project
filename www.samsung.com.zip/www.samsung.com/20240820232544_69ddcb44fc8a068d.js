function li(e) {
var t=e.queryKey,n=t[Rg];if(!x(n))return t;if(N(n))return t;var a=Math.round(q()/1e3);return t[Rg]=n.replace(/\|TS=\d+/,"|TS="+a),t
}