function B(e,t,n) {
switch(t){case Il.GREATER_THAN:return e>n;case Il.GREATER_THAN_OR_EQUAL_TO:return e>=n;case Il.LESS_THAN:return e<n;case Il.LESS_THAN_OR_EQUAL_TO:return e<=n;case Il.EQUALS:return e===n;case Il.NOT_EQUALS:return e!==n;default:return!1}
}