function r() {
return a.logger.debug("a property was read from the computed state at the time of rule execution "+JSON.stringify(d)),window.extensionGoogleDataLayer.dataLayerHelper.get(d)
}