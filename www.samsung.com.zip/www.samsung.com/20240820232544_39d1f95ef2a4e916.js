function j() {
return{matches:function(e,t){var n=arguments.length>2&&void 0!==arguments[2]?arguments[2]:[];if(T(e[t]))return!1;for(var a=String(e[t]).toLowerCase(),r=0;r<n.length;r+=1)if(!T(n[r])&&a.startsWith(String(n[r]).toLowerCase()))return!0;return!1}}
}