function e(e) {
return e.edgeHost?Ru.EDGE:Ru.LOCAL
}