function o() {
return s()?(a.logger.warn(u.ALREADY_INITIALIZED),null):(v.mboxParams=f(),v.globalMboxParams=h(),m(v,c.targetGlobalSettings||{},k),m(v,g||{},["version"]),r(l)||(v.enabled=!1,a.logger.warn(u.DELIVERY_DISABLED)),v.timeout=b(v.timeout),v)
}