function Qo(e) {
var t=e.name,n=la(Gh)||{};n[t]=e,ca(Gh,n)
}