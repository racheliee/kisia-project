function Ee(e) {
return F("#",[Ce(e.name),Ce(e.value),e.expires])
}