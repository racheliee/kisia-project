function NetFunnel_goUrl(c,a,b) {
if(typeof a!="string"){alert("[NetFUNNEL] Invalid input url");return false}if(typeof b!="function")b=function(e,d){return false};NetFunnel_init(null,c);NetFunnel_getTidChkEnter({success:a,error:a,bypass:a,stop:b});return false
}