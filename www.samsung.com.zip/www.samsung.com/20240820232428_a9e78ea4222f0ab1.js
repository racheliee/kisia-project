function S(e,t) {
var n=this,r=new this.constructor(j);void 0===r[O]&&W(r);var o=n._state;if(o){var i=arguments[o-1];a((function(){return N(o,r,i,n._result)}))}else D(n,r,e,t);return r
}