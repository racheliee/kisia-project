function s(e,t) {
return!!t&&!a(e)&&!a(e[h])&&i(e[h])
}