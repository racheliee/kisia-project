function compLayerOpenPlay(elem) {
if($(elem).find("video").length>0)$(elem).find("video").get(0).play()
}