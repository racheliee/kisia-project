function a(e,t,a,s) {
if((t=r(t)).ns)var o=i(t.ns);return(g[n(e)]||[]).filter((function(e){return e&&(!t.e||e.e==t.e)&&(!t.ns||o.test(e.ns))&&(!a||n(e.fn)===n(a))&&(!s||e.sel==s)}))
}