function Pe(e) {
return oe(e)?Ae(e):function(e){if(!ce(e))return Ce(e);var t=[];for(var n in Object(e))Ie.call(e,n)&&"constructor"!=n&&t.push(n);return t}(e)
}