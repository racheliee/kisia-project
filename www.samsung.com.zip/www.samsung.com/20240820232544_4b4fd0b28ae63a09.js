function ue() {
return de(oe)
}