function dd(e) {
var t={};return t.action=mp,t.content=e.content,t.selector=e.selector,t.cssSelector=e.cssSelector,t
}