function setForeignerCookie() {

		setCookie("popForeignerConfirm_1","Y", 7);
	
}