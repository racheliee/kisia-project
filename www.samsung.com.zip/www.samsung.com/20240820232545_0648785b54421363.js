function getBadgeCounterOfPushMessagesCallback(cnt) {

        const alertDiv = $(".cta_alrt ._alrt");
        // cnt > 0 ? alertDiv.show() : alertDiv.hide();
    
}