function GA4ClickNavFooter(obj) {

        try {
            var itemName = $(obj).text();
            var dataOmni = $(obj).closest("ul").parent("li").attr("class") + ":" +  $(obj).data("omni");
            window.dataLayer = window.dataLayer || [];
            window.dataLayer.push({
                event: 'click_nav'  ,    // 필요. 이벤트 GA에 전송
                item_category: 'footer', // 예: 모바일 (an_ac에서 읽기)
                item_name: itemName ,    // 예: 스마트폰(an_la의 마지막깊이에서 읽기)
                an_ca: 'navigation' ,    // 예: should always be navigation
                an_ac: 'footer'     ,    // 예: gnb, footer
                an_la: dataOmni          // 예: <depth 1 value>:<depth 2 value>:<depth 3 value>
            });
            //console.log("GA4 click_nav");
            //console.log(JSON.stringify(dataLayer[dataLayer.length-1]));
            //alert("[GA4 click_nav TEST]\n\n" + JSON.stringify(dataLayer[dataLayer.length-1]));
        } catch (e) {
            // 예외 처리를 위한 삼성의 코드
        }
    
}