function cn(e) {
return Re.apply(void 0,[{cleanup:function(){Ve(e,(function(e){return e.cleanup&&e.cleanup()}))}}].concat(Ft(e)))
}