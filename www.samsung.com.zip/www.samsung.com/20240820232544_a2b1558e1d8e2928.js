function Bc(e) {
var t=e.prefetch,n=(void 0===t?{}:t).views,a=void 0===n?[]:n;D(a)||xc(y(B(Pc,a)))
}