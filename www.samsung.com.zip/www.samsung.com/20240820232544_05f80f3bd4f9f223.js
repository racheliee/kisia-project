function o(e) {
!v&&h&&(v=!0,m.send(a,e))
}