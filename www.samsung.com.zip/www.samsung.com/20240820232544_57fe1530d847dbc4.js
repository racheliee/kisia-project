function pt(e) {
if(p(e[iv]))return!1;var t=e[iv];if(p(t[sv]))return!1;var n=t[sv];return m(n[cv])&&m(n[ov])
}