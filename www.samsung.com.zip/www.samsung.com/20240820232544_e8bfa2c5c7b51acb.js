function ta(e,t) {
return p(e)?{}:ea(e,t)
}