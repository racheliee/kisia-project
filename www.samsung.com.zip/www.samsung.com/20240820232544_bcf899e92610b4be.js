function pv(prefix) {
\n    var path = utils.gpath(prefix);\n    window.gtag('event', 'page_view', {\n      page_location: 'https://' + window.location.hostname + path,\n      page_path: path,\n      send_to: media_track_ids,\n    })\n  }\n\n})();\n",language:"javascript"
}