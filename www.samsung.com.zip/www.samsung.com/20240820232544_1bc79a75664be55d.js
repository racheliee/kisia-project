function gl(e) {
var t=e.status,n=e.data,a={status:t,pageLoad:!0};return p(n)||(a.data=n),a
}