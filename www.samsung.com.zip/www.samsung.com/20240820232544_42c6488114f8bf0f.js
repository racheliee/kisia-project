function ps(e) {
var t=e.request,n=e.response.prefetch;if(!v(n))return ot([]);var a=n.mboxes;return!lu(a)||D(a)?ot([]):dt(B((function(e){return us(t,e)}),_(Ag,a))).then(wg)
}