function Gt(e) {
for(var t,n,a,r,i=[],s=L(e),o=s.indexOf(om);-1!==o;)t=L(s.substring(0,o)),r=(n=L(s.substring(o))).indexOf(cm),a=L(n.substring(lm,r)),o=(s=L(n.substring(r+1))).indexOf(om),t&&a&&i.push({sel:t,eq:Number(a)});return s&&i.push({sel:s}),i
}