function remove(el,opts) {
var count;var full=el==window;var $el=$(el);var data=$el.data("blockUI.history");var to=$el.data("blockUI.timeout");if(to){clearTimeout(to);$el.removeData("blockUI.timeout")}opts=$.extend({},$.blockUI.defaults,opts||{});bind(0,el,opts);
if(opts.onUnblock===null){opts.onUnblock=$el.data("blockUI.onUnblock");$el.removeData("blockUI.onUnblock")}var els;if(full)els=$("body").children().filter(".blockUI").add("body > .blockUI");else els=$el.find(">.blockUI");if(opts.cursorReset){if(els.length>1)els[1].style.cursor=opts.cursorReset;if(els.length>2)els[2].style.cursor=opts.cursorReset}if(full)pageBlock=pageBlockEls=null;if(opts.fadeOut){count=els.length;els.stop().fadeOut(opts.fadeOut,function(){if(--count===0)reset(els,data,opts,el)})}else reset(els,
data,opts,el)
}