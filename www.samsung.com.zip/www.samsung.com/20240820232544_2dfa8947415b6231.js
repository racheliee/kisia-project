function l() {
var e=b[f];return s(u,e)
}