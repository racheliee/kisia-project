function u(e) {
if(Array.isArray(e))return e
}