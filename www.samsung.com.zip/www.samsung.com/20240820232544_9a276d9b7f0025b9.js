function ld(e) {
var t={};return t.action=Vp,t.content=e.content,t.selector=e.selector,t.cssSelector=e.cssSelector,t
}