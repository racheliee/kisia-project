function gs(e) {
var t=e.response,n=t.remoteMboxes,a=t.remoteViews,r=t.decisioningMethod,i={};return v(n)&&(i.remoteMboxes=n),v(a)&&(i.remoteViews=a),x(r)&&(i.decisioningMethod=r),ot(i)
}