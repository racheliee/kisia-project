function Ia(e) {
return ru.default({},e,Sa(Ev.targetPageParamsAll))
}