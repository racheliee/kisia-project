function gcsInducePopup() {

	if(getCookieForSite("mbrNo_1_") != ''){
		 if (getCookieForSite("gcsMbrYn_1_") == 'Y'){
			 gcsToastAjax('gcsWelcomePopup'); // 기가입자 
		 } else if(getCookieForSite("gcsInduceMbrYn_1_") == 'Y'){
			gcsToastAjax('gcsNewPopup'); //가입유도
		}
	}

}