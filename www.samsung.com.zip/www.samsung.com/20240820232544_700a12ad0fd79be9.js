function n() {
var e=0;l="",i.indexOf(s)>=0?$('input:checkbox[name="goodsIds"]').each((function(){this.checked&&(l+=(0===e?"":"@@")+$(this).parents(".boardlist-area").attr("data-omni"),e++)})):i.indexOf(c)>=0&&$('input:checkbox[name="goodsIdArr"]').each((function(){this.checked&&(l+=(0===e?"":"@@")+$(this).parents(".boardlist-area").attr("data-omni"),e++)}))
}