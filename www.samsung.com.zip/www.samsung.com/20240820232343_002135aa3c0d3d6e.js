function GA4SearchSubmit(keyword) {

		try {
			window.dataLayer = window.dataLayer || [];
			window.dataLayer.push({
				event: 'search_submit',
				search_term: keyword,
				search_redirection: "/sec/search/searchresultB2c/?keyword=" + keyword
			});
		} catch (e) {
			// 예외 처리를 위한 삼성의 코드
		}
	}

	$(document).ready(function() {
		var that = searchInputManager;

		
		//2024 웹접근성 심사 기간에는 해당 기능 제거하기로 함
		that.getMainPopularKeyword();
		

		$('#link-search,.search__box,.header__min__search').on('click', function() {
			that.$appendingTarget.autoCompleteCategory.hide();
			
			that.getRecomGoodsB2c(); /* 모바일 퍼스트 추천 제품 */
			
			that.getRecomEventsB2c(); /* 모바일 퍼스트 추천 기획전 */
			that.setRecommendKeyword();
			that.drawSearchHistory();
			
			that.getPopularKeyword();
			

			$('#popularWrap').show();
			$('#searchKeywordWrap').hide();
		});

		$('#unifiedInputSearch').on('keyup', function(e) {
			// 20240528 웹접근성
			var charCode = e.keyCode;
			if (charCode != 9) {
				that.$appendingTarget.searchHistoryWrap.hide();
				that.$appendingTarget.recommendGoodsWrap.hide();
				that.$appendingTarget.recommendEventsWrap.hide();
				$('#popularWrap').hide();
			}
			var $target = $(e.target)
					, keyword = $target.val().replace(/\\/gi, '');
			$target.val(keyword);

			that.getSearchInputAutoComplete(keyword);
			that.getSearchInputAutoCompleteCategory(keyword);
		});

		// 20230622 웹접근성
		$('.btn-close-search').on('keydown', function(e) {
			var charCode = e.keyCode;
			if (charCode == 9) {
				$('.search-box').attr('tabindex', 0).focus();
				$("#accSearch").val("");
			}
		});

		// 20240528 웹접근성 제외처리
		// 20240126 닫기 버튼 추가
		/*
		$('.btn-close-layer').on('keydown', function(e) {
			var charCode = e.keyCode;
			if (charCode == 9) {
				$('.search-box').attr('tabindex', 0).focus();
				$("#accSearch").val("");
			}
		});
		*/
		// 20240528 웹접근성
		$('.btn-close-layer').on('click', function(e) {
			$("div.search__box button.search__button").focus();
		});
		// 20240528 웹접근성
		$(document).on("keydown", "#popularWrap li:last-of-type a", (e) => {
		        $(".search-box").focus();
				$("#accSearch").val("");
	    });
		$('#unifiedInputSearch').on('click', function() { //20210324 추가
			$('.inp-placeholder').hide();
		});

		/* s : 닷컴 웹 검색시 챗봇 검색 연계 구현  jiwon0.id 22.04.26 */
		/* $('.chatbot-search').off('click').on('click', function() {
			let chatbotKeyword;
			if($(this).attr('id') == 'unifiedSearchButton'){
				chatbotKeyword =  $("#unifiedInputSearch").val();
			}else if($(this).attr('id') == 'inputSearchButton'){
				chatbotKeyword =  $("#inputSearch").val();
			}

			if($(this).attr('id') == 'unifiedSearchButton'){
				if(chatbotKeyword == null || chatbotKeyword == ""){
					chatbotKeyword = that.recommendKeyword;
					chat_open4(chatbotKeyword);
				} else{
					chat_open4(chatbotKeyword);
				}
			} else{
				if(chatbotKeyword != null && chatbotKeyword != "") {
					chat_open4(chatbotKeyword);
				}
			
}