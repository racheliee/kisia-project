function t(e,t,n,a) {
t[n]!==a&&(e[n]=t[n])
}