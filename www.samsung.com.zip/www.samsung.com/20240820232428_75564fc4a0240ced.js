function appToastCCClose() {

    setCookieA("toastCYN","N",1);
    setTimeout(function(){$(".cod05-app-banner").remove()},500);

}