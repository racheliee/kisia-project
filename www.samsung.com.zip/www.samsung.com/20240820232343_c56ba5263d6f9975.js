function r() {
o.off(t,r),e.apply(n,arguments)
}