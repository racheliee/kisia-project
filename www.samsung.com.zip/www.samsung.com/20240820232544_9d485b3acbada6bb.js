function G(e,t) {
return N(t)?[]:t.split(e||"")
}