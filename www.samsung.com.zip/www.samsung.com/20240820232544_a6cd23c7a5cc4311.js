function Y(e) {
return!!e.execute&&!!e.execute.mboxes&&e.execute.mboxes.length||0
}