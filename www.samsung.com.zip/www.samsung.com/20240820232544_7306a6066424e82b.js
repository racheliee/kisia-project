function Wc(e) {
var t=e.page;return Nc(Hh,e,t,yc)
}