function gcsToastClose(id) {

    var cookieDay = id == "gcsWelcomePopup" ? 7 : 1;
    var key = encodeURIComponent(getCookieForSite("mbrNo_1_"));
    $("#mask2").remove();
    $('#'+id).removeClass("active");
    var atpc = $("#chk-"+id).is(":checked");
    atpc ? setCookie("gcsToastYN"+"_"+id+'_'+key,"N",cookieDay) : "";

}