function n(e,n) {
var a=t.createEvent("CustomEvent");return n=n||{bubbles:!1,cancelable:!1,detail:void 0},a.initCustomEvent(e,n.bubbles,n.cancelable,n.detail),a
}