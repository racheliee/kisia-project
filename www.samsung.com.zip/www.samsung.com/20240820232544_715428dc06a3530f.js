function Lo(e) {
var t=e.key;if(!N(t)&&Do(e)){var n=e[ap];Ns(rb,t,n)}
}