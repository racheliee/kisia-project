function showLatestItem(self,obj) {
if(device.val!="m"){var $self=$(self);var layer=$("#"+obj);var btnClose=layer.find(".pop-close");layer.attr("tabindex","0").css("display","block");layer.focus();layer.addClass("active");btnClose.click(function(){layer.attr("tabindex","-1");$self.focus();layer.removeClass("active");scrollLock("unlock")})}else layerPopFunc(obj)
}