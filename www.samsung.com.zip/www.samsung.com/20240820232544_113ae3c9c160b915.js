function s(e,n) {
if("undefined"!=typeof document){for(var r={},i=document.cookie?document.cookie.split("; "):[],s=0;s<i.length;s++){var o=i[s].split("="),c=o.slice(1).join("=");n||'"'!==c.charAt(0)||(c=c.slice(1,-1));try{var l=t(o[0]);if(c=(a.read||a)(c,l)||t(c),n)try{c=JSON.parse(c)}catch(e){}if(r[l]=c,e===l)break}catch(e){}}return e?r[e]:r}
}