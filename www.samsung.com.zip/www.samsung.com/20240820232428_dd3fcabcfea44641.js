function Kn() {
return Xt.os.android&&(2==Xt.os.version.major&&/Version\/\d+.\d+|/i.test(Xt.ua)||4==Xt.os.version.major&&Xt.os.version.minor<4&&/Version\/\d+.\d+|/i.test(Xt.ua)||/Version\/\d+\.\d+/i.test(Xt.ua)&&(/Chrome\/\d+\.\d+\.\d+\.\d+ Mobile/i.test(Xt.ua)||/; wv\)/i.test(Xt.ua)))
}