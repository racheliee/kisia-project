function i(e) {
return new RegExp("(?:^| )"+e.replace(" "," .* ?")+"(?: |$)")
}