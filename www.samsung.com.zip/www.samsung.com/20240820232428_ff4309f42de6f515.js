function GA4CompoViewItemList() {

        try {
            var itemList = [];
            $("[data-obj-type='product']:not('.best-rank [data-obj-type=product]'), .best-rank .slick-active [data-obj-type='product']").each(function(){
                var mdlCode = $(this).data("mo-code");
                var goodsNm = $(this).data("goods-nm");
                var dispCtgEnNmPath = $(this).data("disp-ctg-en-nm-path");
                var dispCtgEnNmPathArr = "";
                if(dispCtgEnNmPath != undefined){
                    dispCtgEnNmPathArr = dispCtgEnNmPath.split(">");
                }
                var itemCategory1 = dispCtgEnNmPathArr[0] != undefined ? dispCtgEnNmPathArr[0].trim() : '';
                var itemCategory2 = dispCtgEnNmPathArr[1] != undefined ? dispCtgEnNmPathArr[1].trim() : '';
                var itemCategory3 = dispCtgEnNmPathArr[2] != undefined ? dispCtgEnNmPathArr[2].trim() : '';
                var itemCategory4 = dispCtgEnNmPathArr[3] != undefined ? dispCtgEnNmPathArr[3].trim() : '';
                var itemCategory5 = dispCtgEnNmPathArr[4] != undefined ? dispCtgEnNmPathArr[4].trim() : '';
                
                var idx            = $("[data-obj-type='product'").index($(this));
                var cpAllDcAmt     = $(this).attr("data-cp-all-dc-amt")     != undefined ? $(this).data("cp-all-dc-amt")     : '0';
                var cpAplExptPrice = $(this).attr("data-cp-apl-expt-price") != undefined ? $(this).data("cp-apl-expt-price") : '0';
                
                if($(this).parents("[data-cp-apl-expt-price]").length > 0){
                    cpAplExptPrice = $(this).parents("[data-cp-apl-expt-price]").data("cp-apl-expt-price");
                } else if ($(this).parents("[id^=rankingPdCardList_]").length > 0) {
                    cpAplExptPrice = $(this).find(".component-price > dl > dd > span > em").text();
                } else {
                    cpAplExptPrice = 0;
                }
                
                var item = {
                             item_id        : mdlCode,
                             item_name      : goodsNm,
                             item_brand     : 'Samsung',
                             item_category  : itemCategory1,
                             item_category2 : itemCategory2,
                             item_category3 : itemCategory3,
                             item_category4 : itemCategory4,
                             item_category5 : itemCategory5,
                             item_variant   : '',
                             item_list_name : '',
                             item_list_id   : '',
                             quantity       : '1',
                             price          : cpAplExptPrice,
                             currency       : 'KRW',
                             discount       : cpAllDcAmt,
                             index          : idx                                        
                          };
                itemList.push(item);
            });
            
            window.dataLayer = window.dataLayer || [];
            window.dataLayer.push({
                event    : 'view_item_list',
                ecommerce: {
                  items: itemList
                }
            });
            //console.log("GA4 view_item_list");
            //console.log(JSON.stringify(dataLayer[dataLayer.length-1]));
            //alert("[GA4 view_item_list TEST]\n\n" + JSON.stringify(dataLayer[dataLayer.length-1]));
        } catch (e) {
            // 예외 처리를 위한 삼성의 코드
        }
    
}