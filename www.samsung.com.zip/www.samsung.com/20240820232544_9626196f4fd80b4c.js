function Pi(e) {
return Ci(wi(e.content,{},ke()[Kg])).then(xi).catch((function(){return null}))
}