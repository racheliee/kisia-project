function G(e,t,n,a) {
var r=n;return e.every((function(e){var n=q(e,Ll);if(!n)return!1;var i=t.events[n];if(!i)return!1;var s=q(e,Nl);if(!s)return!1;var o=i[s];if(!U(e,o))return!1;if(null===o||F(o)||0===o.count)return!1;var c=(F(r)||o.timestamp>=r)&&(F(a)||o.timestamp<=a);return r=o.timestamp,c}))?1:0
}