function floatingPfpdCompareNormalPosition(setPositionNum) {
if($(".pfpd-compare").hasClass("close")){$(".floating-sticky").css("margin-bottom",setPositionNum);setTimeout(function(){toastH=$(".pfpd-compare").outerHeight();bnbH=$("#bottom__navi").outerHeight()||0;$(".floating-sticky").css("margin-bottom",toastH+bnbH)},500)}else if($(".pfpd-compare").hasClass("open")){$(".floating-sticky").css("margin-bottom",setPositionNum);setTimeout(function(){toastH=$(".pfpd-compare").outerHeight();bnbH=$("#bottom__navi").outerHeight()||
0;$(".floating-sticky").css("margin-bottom",toastH+bnbH)},500)}
}