function s(e) {
a=e
}