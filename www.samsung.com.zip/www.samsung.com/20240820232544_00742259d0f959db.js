function s() {
return c.adobe&&c.adobe.target&&void 0!==c.adobe.target.getOffer
}