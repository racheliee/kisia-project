function windowWidthSlick() {

			$(".box-story .box-slide").slick({
				dots: true,
				arrows: false,
				fade: true,
				infinite: false,
				speed: 0,
				responsive: [
					{
						breakpoint: 801,
						settings: {
							fade: false,
							speed: 300,
						}
					}
				]
			});
			$(".box-story .txt-box").on("mouseenter", function(){
				var slideNo = $(this).parents(".box-item").index();
				$(".box-story .box-slide").slick("slickGoTo", slideNo);
			});
			$(".box-story .box-slide").on('afterChange', function(event, slick, currentSlide, nextSlide){
				$(".box-story .picture").removeClass("z-index-up");
	
				if($(this).parents(".popup-comp-player").length > 0) {
					var video = $(this).parents(".popup-comp-player").find("video");
					if(video.length > 0) video.get(0).pause();
				}
				$(".popup-comp-player").hide();
			});
		
}