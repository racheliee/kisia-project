function hn(e) {
var t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:Bv,n=fn(e.location.search);if(!p(n)){var a=new Date(q()+186e4),r=ke(),i=r[gh],s=r[Vh],o=ru.default({expires:a,secure:i,domain:s},i?{sameSite:Vv}:{});t(mm,JSON.stringify(n),o)}
}