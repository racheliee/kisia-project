function getCouponCnt() {

        $.ajax({
             url : "/sec/xhr/coupon/getCouponInOrderCnt"
           , type : "POST"
           , success : function(result) {
                 $("[name=couponCnt]").text(result);
             }
        });
    
}