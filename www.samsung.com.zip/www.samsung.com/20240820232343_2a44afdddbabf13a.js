function once(func) {

		var flag
				, result;

		return function() {
			if ( flag ) {
				return result;
			}
			flag = true;
			return result = func.apply(this);
		}
	}

	/* s : 20200917 수정 */
	var searchLinkforApp = once(function() {
		var that = searchInputManager;

		that.setRecommendKeyword();
		that.drawSearchHistory();
		
		
		that.getPopularKeyword();
		

	});

	function searchOpenforApp() { // 20200917 추가
		searchLinkforApp();
		headerSearch.eventListener.uinifiedSearchOpen();
	}
	/* e : 20200917 수정 */

	/* e: APP용 함수 */

	/* s : 닷컴 웹 검색시 챗봇 검색 연계 구현  jiwon0.id 22.04.26 */
	function chat_open4(chatbotKeyword) {
		var isMobile = false; // 모바일 여부
		var filter = "win16|win32|win64|mac|macintel"; // PC 환경

		// 모바일,태블릿 / PC 환경 구분
		if(navigator.platform){
			isMobile = filter.indexOf(navigator.platform.toLowerCase()) < 0
		}

		if(!isMobile){
			var birthAge = null;
			var birthDate = $.cookie("birthDate_1_");

			if(birthDate != 0 && birthDate != null){
				birthAge = checkAge(birthDate);
			}

			if(birthAge >= 14 || birthAge == 0 || birthAge == null) {
				var agepass = checkAgepass(birthAge);
				fcTrack('click','floating chat:chat online');

				var keyword = encodeURIComponent(chatbotKeyword);
				var popupX = (window.screen.width / 2) - (356 / 2);
				var popupY = (window.screen.height / 2) - (750 / 2);

				window.open('/sec/chatbot/?keyword='+ keyword+'&agepass='+agepass, '_chatbot4', 'status=no, height=750, width=356, left=' + popupX + ', top=' + popupY + ', screenX=' + popupX + ', screenY= ' + popupY);
			}
		}
	}
	/* e : 닷컴 웹 검색시 챗봇 검색 연계 구현  jiwon0.id 22.04.26 */

	/* s : 만 나이 구하는 함수 @param birthDate : 생년월일  jiwon0.id 22.05.17 */
	function checkAge(birthDate){
		const today = new Date(); //현재날짜
		birthDate = (birthDate + "")

		var age = today.getFullYear() - Number(birthDate.slice(0,4)); 	//나이
		var mon = (today.getMonth()+1) - Number(birthDate.slice(4,6));	//월
		//생일 안지났으면 -1
		if(mon < 0 || (mon === 0 && today.getDate() < Number(birthDate.slice(6,8)))) {
			age = age -1;
		}
		return age;
	}
	/* e : 만 나이 구하는 함수 @param birthDate : 생년월일  jiwon0.id 22.05.17 */

	/* s : 만 나이별로 agepass 구분값 설정 함수 @param birthAge : 만나이   14세 이상 : 'y'   로그인하지 않을경우 : 'u'   jiwon0.id 22.06.09 */
	function checkAgepass(birthAge){
		var agepass = null;

		if( birthAge == 0 || birthAge == null ) {
			agepass = "u";
		} else if(birthAge >= 14) {
			agepass = "y";
		}

		return agepass
	}
	/* e : 만 나이별로 agepass 구분값 설정 함수  jiwon0.id 22.06.09 */

	function GA4SearchSubmit(keyword) {
		try {
			window.dataLayer = window.dataLayer || [];
			window.dataLayer.push({
				event: 'search_submit',
				search_term: keyword,
				search_redirection: "/sec/search/searchresultB2c/?keyword=" + keyword
			});
		} catch (e) {
			// 예외 처리를 위한 삼성의 코드
		}
	}

	$(document).ready(function() {
		var that = searchInputManager;

		
		//2024 웹접근성 심사 기간에는 해당 기능 제거하기로 함
		that.getMainPopularKeyword();
		

		$('#link-search,.search__box,.header__min__search').on('click', function() {
			that.$appendingTarget.autoCompleteCategory.hide();
			
			that.getRecomGoodsB2c(); /* 모바일 퍼스트 추천 제품 */
			
			that.getRecomEventsB2c(); /* 모바일 퍼스트 추천 기획전 */
			that.setRecommendKeyword();
			that.drawSearchHistory();
			
			that.getPopularKeyword();
			

			$('#popularWrap').show();
			$('#searchKeywordWrap').hide();
		});

		$('#unifiedInputSearch').on('keyup', function(e) {
			// 20240528 웹접근성
			var charCode = e.keyCode;
			if (charCode != 9) {
				that.$appendingTarget.searchHistoryWrap.hide();
				that.$appendingTarget.recommendGoodsWrap.hide();
				that.$appendingTarget.recommendEventsWrap.hide();
				$('#popularWrap').hide();
			}
			var $target = $(e.target)
					, keyword = $target.val().replace(/\\/gi, '');
			$target.val(keyword);

			that.getSearchInputAutoComplete(keyword);
			that.getSearchInputAutoCompleteCategory(keyword);
		});

		// 20230622 웹접근성
		$('.btn-close-search').on('keydown', function(e) {
			var charCode = e.keyCode;
			if (charCode == 9) {
				$('.search-box').attr('tabindex', 0).focus();
				$("#accSearch").val("");
			}
		});

		// 20240528 웹접근성 제외처리
		// 20240126 닫기 버튼 추가
		/*
		$('.btn-close-layer').on('keydown', function(e) {
			var charCode = e.keyCode;
			if (charCode == 9) {
				$('.search-box').attr('tabindex', 0).focus();
				$("#accSearch").val("");
			}
		});
		*/
		// 20240528 웹접근성
		$('.btn-close-layer').on('click', function(e) {
			$("div.search__box button.search__button").focus();
		});
		// 20240528 웹접근성
		$(document).on("keydown", "#popularWrap li:last-of-type a", (e) => {
		        $(".search-box").focus();
				$("#accSearch").val("");
	    });
		$('#unifiedInputSearch').on('click', function() { //20210324 추가
			$('.inp-placeholder').hide();
		});

		/* s : 닷컴 웹 검색시 챗봇 검색 연계 구현  jiwon0.id 22.04.26 */
		/* $('.chatbot-search').off('click').on('click', function() {
			let chatbotKeyword;
			if($(this).attr('id') == 'unifiedSearchButton'){
				chatbotKeyword =  $("#unifiedInputSearch").val();
			}else if($(this).attr('id') == 'inputSearchButton'){
				chatbotKeyword =  $("#inputSearch").val();
			}

			if($(this).attr('id') == 'unifiedSearchButton'){
				if(chatbotKeyword == null || chatbotKeyword == ""){
					chatbotKeyword = that.recommendKeyword;
					chat_open4(chatbotKeyword);
				} else{
					chat_open4(chatbotKeyword);
				}
			} else{
				if(chatbotKeyword != null && chatbotKeyword != "") {
					chat_open4(chatbotKeyword);
				}
			
}